<?php
   /**
    * The template for displaying all single posts
    *
    * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
    *
    * @package Taj
    */

   get_header();

   global $taj_options;

   if ($taj_options['taj_page_titles_switch']) {
       echo do_shortcode($taj_options['taj_page_titles_shortcode']);
   }

   ?>

<div class="container taj-wrap">

    <div class="row">
        <!-- Right Sidebar -->
        <?php if ($taj_options['post_layout'] == 3): ?>
        <div class="col-md-3">
            <?php
               get_sidebar();
            ?>
        </div>
        <?php endif; ?>

        <!-- No Sidebar -->
        <?php if ($taj_options['post_layout'] == 1): ?>
        <div class="col-md-12">

            <!-- Right or Left Sidebar -->
            <?php else: ?>
            <div class="col-md-9">
                <?php endif; ?>

                <main id="primary" class="site-main">
                    <?php
               while (have_posts()) :
                   the_post();

                   get_template_part('/template-parts/content', get_post_type());

                   /* Show Social Sharing Section */
                   if($taj_options['social_switch']) {
                       require_once locate_template('/inc/features/social-sharing.php');
                   }

                   the_post_navigation(
                       array(
                           'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'taj') . '</span> <span class="nav-title">%title</span>',
                           'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'taj') . '</span> <span class="nav-title">%title</span>',
                       )
                   );

                   /* Show Related Posts Section */
                   if($taj_options['related_switch']) {
                       require_once locate_template('/inc/features/related-posts.php');
                   }

                   // If comments are open or we have at least one comment, load up the comment template.
                   if ($taj_options['comments_switch'] && (comments_open() || get_comments_number())) :
                       comments_template();
                   endif;

               endwhile; // End of the loop.
   ?>
                </main>
                <!-- #main -->
            </div>

            <!-- Left Sidebar -->
            <?php if ($taj_options['post_layout'] == 2): ?>
            <div class="col-md-3">
                <?php
            get_sidebar();
                ?>
            </div>
            <?php endif; ?>

        </div>

    </div>

    <?php
get_footer();
