<?php
/**
 * Taj Theme Control Panel
 *
 * @package taj
 */

if (! class_exists('Redux')) {
    return;
}

// This is your option name where all the Redux data is stored.
$opt_name = 'taj_options';

Redux::disable_demo();

/**
 * GLOBAL ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: @link https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 */

/**
 * ---> BEGIN ARGUMENTS
 */


$theme = wp_get_theme(); // For use with some settings. Not necessary.
$ss = '<i class="fa fa-angle-up" aria-hidden="true"></i>';

$args = array(
    // REQUIRED!!  Change these values as you need/desire.
    'opt_name'                  => $opt_name,

    // Name that appears at the top of your panel.
    'display_name'              => esc_html__('Welcome to the Taj Control Panel', 'taj'),

    // Version that appears at the top of your panel.
    'display_version'           => '',

    // Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only).
    'menu_type'                 => 'menu',

    // Show the sections below the admin menu item or not.
    'allow_sub_menu'            => true,

    'menu_title'                => esc_html__('Taj', 'taj'),
    'page_title'                => esc_html__('Taj', 'taj'),

    // Disable this in case you want to create your own google fonts loader.
    'disable_google_fonts_link' => false,

    // Show the panel pages on the admin bar.
    'admin_bar'                 => true,

    // Choose an icon for the admin bar menu.
    'admin_bar_icon'            => 'dashicons-portfolio',

    // Choose an priority for the admin bar menu.
    'admin_bar_priority'        => 50,

    // Set a different name for your global variable other than the opt_name.
    'global_variable'           => '',

    // Show the time the page took to load, etc.
    'dev_mode'                  => false,

    // Enable basic customizer support.
    'customizer'                => true,

    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_priority'             => 60,

    // For a full list of options, visit: @link http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters.
    'page_parent'               => 'themes.php',

    // Permissions needed to access the options panel.
    'page_permissions'          => 'manage_options',

    // Specify a custom URL to an icon.
    'menu_icon'                 => content_url() . '/themes/taj/admin/taj.png',

    // Force your panel to always open to a specific tab (by id).
    'last_tab'                  => '',

    // Icon displayed in the admin panel next to your menu_title.
    'page_icon'                 => 'icon-themes',

    // Page slug used to denote the panel.
    'page_slug'                 => 'taj_options',

    // On load save the defaults to DB before user clicks save or not.
    'save_defaults'             => true,

    // If true, shows the default value next to each field that is not the default value.
    'default_show'              => false,

    // What to print by the field's title if the value shown is default. Suggested: *.
    'default_mark'              => '',

    // Shows the Import/Export panel when not used as a field.
    'show_import_export'        => true,

    // CAREFUL -> These options are for advanced use only.
    'transient_time'            => 60 * MINUTE_IN_SECONDS,

    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output.
    'output'                    => true,

    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head.
    'output_tag'                => true,

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'database'                  => '',

    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
    'use_cdn'                   => true,
    'compiler'                  => true,

    // Enable or disable flyout menus when hovering over a menu with submenus.
    'flyout_submenus'           => true,

    // Mode to display fonts (auto|block|swap|fallback|optional)
    // See: https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display
    'font_display'              => 'swap',

    // HINTS.
    'hints'                     => array(
        'icon'          => 'el el-question-sign',
        'icon_position' => 'left',
        'icon_color'    => 'lightgray',
        'icon_size'     => 'normal',
        'tip_style'     => array(
            'color'   => 'dark',
            'shadow'  => true,
            'rounded' => true,
            'style'   => '',
        ),
        'tip_position'  => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect'    => array(
            'show' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'mouseover',
            ),
            'hide' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'click mouseleave',
            ),
        ),
    ),
);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
/*$args['admin_bar_links'][] = array(
    'id'    => 'taj-docs',
    'href'  => 'https://taj.wp-arabi.com/docs',
    'title' => esc_html__('Documentation', 'taj'),
);*/

// Panel Intro text -> before the form.

$args['intro_text'] = '<p>' . esc_html__('On this page you can control the theme settings.', 'taj') . '</p>';


// Add content after the form.
$args['footer_text'] = '<p>' . esc_html__('Thank you for creating with Taj Theme.', 'taj') . '</p>';

Redux::set_args($opt_name, $args);

/*
 * ---> END ARGUMENTS
 */

/*
 *
 * ---> BEGIN SECTIONS
 *
 */

/* As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for. */

/* -> START Basic Fields. */

$kses_exceptions = array(
    'a'      => array(
        'href' => array(),
    ),
    'strong' => array(),
    'br'     => array(),
);


$section = array(
    'title' => __('General Settings', 'taj'),
    'id'    => 'General_settings',
    'desc'  => __('Here you can control the general settings of your site.', 'taj'),
    'icon'  => 'el el-cog-alt',
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Header Settings', 'taj'),
    'id'     => 'header_settings',
    'subsection' => true,
    'icon'   => 'el el-file-edit-alt',
    'fields' => array(
        array(
            'id' => 'header_info',
            'type' => 'info',
            'style' => 'info',
            'icon'   => 'el el-info-circle',
            'title' => esc_html__('Note:', 'taj'),
            'desc' => esc_html__('To edit the header, go to: Appearance > Elementor Header & Footer Builder > Main Header.', 'taj') . "<br>" . esc_html__('For more information, please check the theme documentation.', 'taj')
        ),

    ),

);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Footer Settings', 'taj'),
    'id'     => 'footer_settings',
    'subsection' => true,
    'icon'   => 'el el-file-edit-alt',
    'fields' => array(
        array(
            'id' => 'footer_info',
            'type' => 'info',
            'style' => 'info',
            'icon'   => 'el el-info-circle',
            'title' => esc_html__('Note:', 'taj'),
            'desc' => esc_html__('To edit the footer, go to: Appearance > Elementor Header & Footer Builder > Main Footer.', 'taj') . "<br>" . esc_html__('For more information, please check the theme documentation.', 'taj')
        ),
    ),

);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Page Titles Settings', 'taj'),
    'id'     => 'page_titles_settings',
    'subsection' => true,
    'icon'   => 'el el-file-edit-alt',
    'fields' => array(
        array(
            'id'       => 'taj_page_titles_switch',
            'type'     => 'switch',
            'title'    => esc_html__("Show Page Titles on Theme's  general pages", 'taj'),
            'on' => esc_html__('Show', 'taj'),
            'off' => esc_html__('Hide', 'taj'),
            'default'  => true,
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__("Example of theme's  general pages: blog page and 404 page (which is not built via the Elementor page builder).", 'taj'),
        ),
        ),
        array(
            'id'       => 'taj_page_titles_shortcode',
            'type'     => 'text',
            'title'    => esc_html__('Page Titles Shortcode', 'taj'),
            'default'  => '',
        ),
        array(
            'id' => 'page_titles_info',
            'type' => 'info',
            'style' => 'info',
            'icon'   => 'el el-info-circle',
            'title' => esc_html__('Note:', 'taj'),
            'desc' => esc_html__('To edit the page titles, go to: Appearance > Elementor Header & Footer Builder > Page Titles.', 'taj') . "<br>" . esc_html__('For more information, please check the theme documentation.', 'taj')
        ),
    ),

);
Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Colors Settings', 'taj'),
    'id'     => 'colors_settings',
    'desc'   => esc_html__("Select the colors of the theme's general pages (eg: blog page and 404 page).", 'taj'),
    'icon'   => 'el  el-brush',
    'fields' => array(
        array(
            'id'       => 'taj_primary_color',
            'type'     => 'color',
            'title'    => esc_html__('Primary Color', 'taj'),
            'default'  => '#f24835',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id'       => 'taj_secondary_color',
            'type'     => 'color',
            'title'    => esc_html__('Secondary Color', 'taj'),
            'default'  => '#fdd100',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id'       => 'taj_hover_color',
            'type'     => 'color',
            'title'    => esc_html__('Hover Color', 'taj'),
            'default'  => '#fdd100',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id'       => 'taj_selection_color',
            'type'     => 'color',
            'title'    => esc_html__('Selection Color', 'taj'),
            'default'  => '#fdd100',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id'       => 'taj_default_background_color',
            'type'     => 'color',
            'title'    => esc_html__('Default Background Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id'       => 'taj_widget_background_color',
            'type'     => 'color',
            'title'    => esc_html__('Widget Background Color', 'taj'),
            'default'  => '#f24835',
            'transparent' => false,
            'color_alpha' => true,
        ),
        array(
            'id' => 'colors_info',
            'type' => 'info',
            'style' => 'info',
            'icon'   => 'el el-info-circle',
            'title' => esc_html__('Note:', 'taj'),
            'desc' => esc_html__("You can modify the colors of the pages that have been built via the Elementor page builder with a single click easily by following these steps:", "taj") . "<br>" . esc_html__("1- Start editing any page with Elementor.", "taj") . "<br>" . esc_html__("2- Click the menu icon.", "taj") . "<br>" . esc_html__("3- Go to Site Settings.", "taj") . "<br>" . esc_html__("4- Go to Global Colors.", "taj") . "<br>" . esc_html__("For more information, please check the theme documentation.", "taj")
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title' => __('Fonts Settings', 'taj'),
    'id'    => 'fonts_settings',
    'desc'  => __('Here you can adjust the fonts of your site.', 'taj'),
    'icon'  => 'el  el-pencil-alt
	',
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Website Font', 'taj'),
    'id'     => 'taj_website_font',
    'subsection' => true,
    'desc'   => esc_html__('Here you can choose the site font.', 'taj'),
    'icon'   => 'el el-website-alt',
    'fields' => array(
        array(
            'id'       => 'taj_website_font_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
        array(
            'id'       => 'taj_website_font_family',
            'type'     => 'select',
            'title'    => esc_html__('Select Font Family', 'taj'),
            // Must provide key => value pairs for select options
            'options'  => array(
                'rabar' => esc_html__('rabar', 'taj'),
                'hanimation' => esc_html__('hanimation', 'taj'),
                'althawra-fikra-bold' => esc_html__('althawra-fikra-bold', 'taj'),
                'althawra-fikra' => esc_html__('althawra-fikra', 'taj'),
                'mehrajan' => esc_html__('mehrajan', 'taj'),
                'cocon-next-arabic' => esc_html__('cocon-next-arabic', 'taj'),
                'kawkab' => esc_html__('kawkab', 'taj'),
                'kawkab-light' => esc_html__('kawkab-light', 'taj'),
                'kawkab-bold' => esc_html__('kawkab-bold', 'taj'),
                'geeza-pro-bold' => esc_html__('geeza-pro-bold', 'taj'),
                'geeza-pro' => esc_html__('geeza-pro', 'taj'),
                'dubai' => esc_html__('dubai', 'taj'),
                'dubai-light' => esc_html__('dubai-light', 'taj'),
                'dubai-medium' => esc_html__('dubai-medium', 'taj'),
                'dubai-bold' => esc_html__('dubai-bold', 'taj'),
                'rsail' => esc_html__('rsail', 'taj'),
                'rsail-bold' => esc_html__('rsail-bold', 'taj'),
                'rsail-light' => esc_html__('rsail-light', 'taj'),
                'arabswell-1' => esc_html__('arabswell-1', 'taj'),
                'rabat' => esc_html__('rabat', 'taj'),
                'sky-bold' => esc_html__('sky-bold', 'taj'),
                'sara' => esc_html__('sara', 'taj'),
                'neckar-bold' => esc_html__('neckar-bold', 'taj'),
                'neckar' => esc_html__('neckar', 'taj'),
                'shahd-bold' => esc_html__('shahd-bold', 'taj'),
                'shahd' => esc_html__('shahd', 'taj'),
                'alhurra' => esc_html__('alhurra', 'taj'),
                'rawy-bold' => esc_html__('rawy-bold', 'taj'),
                'rawy-thin' => esc_html__('rawy-thin', 'taj'),
                'alnaqaa' => esc_html__('alnaqaa', 'taj'),
                'sabgha' => esc_html__('sabgha', 'taj'),
                'vip-hakm-bold' => esc_html__('vip-hakm-bold', 'taj'),
                'vip-hakm-thin' => esc_html__('vip-hakm-thin', 'taj'),
                'vip-hakm' => esc_html__('vip-hakm', 'taj'),
                'smartman' => esc_html__('smartman', 'taj'),
                'zahra-bold' => esc_html__('zahra-bold', 'taj'),
                'zahra' => esc_html__('zahra', 'taj'),
                'sadiyah' => esc_html__('sadiyah', 'taj'),
                'shams' => esc_html__('shams', 'taj'),
                'almushaf' => esc_html__('almushaf', 'taj'),
                'thuluth-decorated' => esc_html__('thuluth-decorated', 'taj'),
                'stoor' => esc_html__('stoor', 'taj'),
                'vip-tim-black' => esc_html__('vip-tim-black', 'taj'),
                'vip-tim-bold' => esc_html__('vip-tim-bold', 'taj'),
                'vip-tim' => esc_html__('vip-tim', 'taj'),
                'vip-tim-light' => esc_html__('vip-tim-light', 'taj'),
                'mirza-medium' => esc_html__('mirza-medium', 'taj'),
                'mirza-bold' => esc_html__('mirza-bold', 'taj'),
                'mirza' => esc_html__('mirza', 'taj'),
                'mada-light' => esc_html__('mada-light', 'taj'),
                'mada-bold' => esc_html__('mada-bold', 'taj'),
                'mada' => esc_html__('mada', 'taj'),
                'lemonada-light' => esc_html__('lemonada-light', 'taj'),
                'lemonada-bold' => esc_html__('lemonada-bold', 'taj'),
                'lemonada' => esc_html__('lemonada', 'taj'),
                'elmessiri-light' => esc_html__('elmessiri-light', 'taj'),
                'elmessiri-bold' => esc_html__('elmessiri-bold', 'taj'),
                'elmessiri' => esc_html__('elmessiri', 'taj'),
                'cairo-bold' => esc_html__('cairo-bold', 'taj'),
                'cairo-extra-light' => esc_html__('cairo-extra-light', 'taj'),
                'cairo-light' => esc_html__('cairo-light', 'taj'),
                'cairo' => esc_html__('cairo', 'taj'),
                'aref-ruqaa' => esc_html__('aref-ruqaa', 'taj'),
                'jazeera-light' => esc_html__('jazeera-light', 'taj'),
                'reem-kufi' => esc_html__('reem-kufi', 'taj'),
                'katibeh' => esc_html__('katibeh', 'taj'),
                'harmattan' => esc_html__('harmattan', 'taj'),
                'jomhuria' => esc_html__('jomhuria', 'taj'),
                'rakkas' => esc_html__('rakkas', 'taj'),
                'tasmeem-med' => esc_html__('tasmeem-med', 'taj'),
                'helal' => esc_html__('helal', 'taj'),
                'homa' => esc_html__('homa', 'taj'),
                'setareh' => esc_html__('setareh', 'taj'),
                'shiraz' => esc_html__('shiraz', 'taj'),
                'omar' => esc_html__('omar', 'taj'),
                'sky' => esc_html__('sky', 'taj'),
                'arwa' => esc_html__('arwa', 'taj'),
                'tachkili' => esc_html__('tachkili', 'taj'),
                'israr-syria' => esc_html__('israr-syria', 'taj'),
                'sukar-black' => esc_html__('sukar-black', 'taj'),
                'sukar-bold' => esc_html__('sukar-bold', 'taj'),
                'sukar' => esc_html__('sukar', 'taj'),
                'bokra' => esc_html__('bokra', 'taj'),
                'bahij' => esc_html__('bahij', 'taj'),
                'motairah-light' => esc_html__('motairah-light', 'taj'),
                'motairah' => esc_html__('motairah', 'taj'),
                'bedayah' => esc_html__('bedayah', 'taj'),
                'tanseek' => esc_html__('tanseek', 'taj'),
                'sheba' => esc_html__('sheba', 'taj'),
                'saudi' => esc_html__('saudi', 'taj'),
                'ishraq' => esc_html__('ishraq', 'taj'),
                'mbc' => esc_html__('mbc', 'taj'),
                'thameen' => esc_html__('thameen', 'taj'),
                'milano' => esc_html__('milano', 'taj'),
                'jordan' => esc_html__('jordan', 'taj'),
                'yassin' => esc_html__('yassin', 'taj'),
                'bein-normal' => esc_html__('bein-normal', 'taj'),
                'bein' => esc_html__('bein', 'taj'),
                'taha-naskh' => esc_html__('taha-naskh', 'taj'),
                'droid-naskh' => esc_html__('droid-naskh', 'taj'),
                'baran' => esc_html__('baran', 'taj'),
                'ghala-bold' => esc_html__('ghala-bold', 'taj'),
                'ghala' => esc_html__('ghala', 'taj'),
                'kamran' => esc_html__('kamran', 'taj'),
                'al-majd' => esc_html__('al-majd', 'taj'),
                'shekari' => esc_html__('shekari', 'taj'),
                'almawadah' => esc_html__('almawadah', 'taj'),
                'kacst-farsi' => esc_html__('kacst-farsi', 'taj'),
                'motken' => esc_html__('motken', 'taj'),
                'insan' => esc_html__('insan', 'taj'),
                'fixed-kufi' => esc_html__('fixed-kufi', 'taj'),
                'esfahan' => esc_html__('esfahan', 'taj'),
                'fantezy' => esc_html__('fantezy', 'taj'),
                'bdavat' => esc_html__('bdavat', 'taj'),
                'Ibtisam' => esc_html__('Ibtisam', 'taj'),
                'shorooq' => esc_html__('shorooq', 'taj'),
                'toyor-aljanah' => esc_html__('toyor-aljanah', 'taj'),
                'spirit-of-doha' => esc_html__('spirit-of-doha', 'taj'),
                'hayah' => esc_html__('hayah', 'taj'),
                'muslimah' => esc_html__('muslimah', 'taj'),
                'alhorr' => esc_html__('alhorr', 'taj'),
                'lamar' => esc_html__('lamar', 'taj'),
                'yaraa-regular' => esc_html__('yaraa-regular', 'taj'),
                'yaraa' => esc_html__('yaraa', 'taj'),
                'aures' => esc_html__('aures', 'taj'),
                'maghrebi' => esc_html__('maghrebi', 'taj'),
                'nawar' => esc_html__('nawar', 'taj'),
                'maidan' => esc_html__('maidan', 'taj'),
                'jannat' => esc_html__('jannat', 'taj'),
                'diana-regular' => esc_html__('diana-regular', 'taj'),
                'diana-light' => esc_html__('diana-light', 'taj'),
                'aqeeq' => esc_html__('aqeeq', 'taj'),
                'alshohadaa' => esc_html__('alshohadaa', 'taj'),
                'alqusair' => esc_html__('alqusair', 'taj'),
                'bon' => esc_html__('bon', 'taj'),
                'asmaa' => esc_html__('asmaa', 'taj'),
                'taqniya' => esc_html__('taqniya', 'taj'),
                'assaf' => esc_html__('assaf', 'taj'),
                'albayan' => esc_html__('albayan', 'taj'),
                'hala' => esc_html__('hala', 'taj'),
                'osama' => esc_html__('osama', 'taj'),
                'baghdad' => esc_html__('baghdad', 'taj'),
                'algeria' => esc_html__('algeria', 'taj'),
                'noorehuda' => esc_html__('noorehuda', 'taj'),
                'themixarab' => esc_html__('themixarab', 'taj'),
                'strick' => esc_html__('strick', 'taj'),
                'rawi' => esc_html__('rawi', 'taj'),
                'jazeera' => esc_html__('jazeera', 'taj'),
                'droid-sans' => esc_html__('droid-sans', 'taj'),
                'lateef' => esc_html__('lateef', 'taj'),
                'Noto-Urdu' => esc_html__('Noto-Urdu', 'taj'),
                'Thabit' => esc_html__('Thabit', 'taj'),
                'b-sepideh' => esc_html__('b-sepideh', 'taj'),
                'boutros-ads' => esc_html__('boutros-ads', 'taj'),
                'stc' => esc_html__('stc', 'taj'),
                'diwanltr' => esc_html__('diwanltr', 'taj'),
                'barabics' => esc_html__('barabics', 'taj'),
                'btehran' => esc_html__('btehran', 'taj'),
                'fanni' => esc_html__('fanni', 'taj'),
                'kufi' => esc_html__('kufi', 'taj'),
                'jooza' => esc_html__('jooza', 'taj'),
                'hama' => esc_html__('hama', 'taj'),
                'DroidKufi-Regular' => esc_html__('DroidKufi-Regular', 'taj'),
                'amiri-quran' => esc_html__('amiri-quran', 'taj'),
                'amiri-slanted' => esc_html__('amiri-slanted', 'taj'),
                'amiri-bold' => esc_html__('amiri-bold', 'taj'),
                'amiri' => esc_html__('amiri', 'taj'),
                'Old-Antic-Bold' => esc_html__('Old-Antic-Bold', 'taj'),
                'farsi-simple-bold' => esc_html__('farsi-simple-bold', 'taj'),
                'diwani-bent' => esc_html__('diwani-bent', 'taj'),
                'ah-moharram-bold' => esc_html__('ah-moharram-bold', 'taj'),
                'b-hamid' => esc_html__('b-hamid', 'taj'),
                'al-gemah-alhoda' => esc_html__('al-gemah-alhoda', 'taj'),
                'old-antic-decorative' => esc_html__('old-antic-decorative', 'taj'),
                'b-compset' => esc_html__('b-compset', 'taj'),
                'decotype-thuluth' => esc_html__('decotype-thuluth', 'taj'),
                'hamada' => esc_html__('hamada', 'taj'),
                'basim-marah' => esc_html__('basim-marah', 'taj'),
                'flat-jooza' => esc_html__('flat-jooza', 'taj'),
                'g-Almarai' => esc_html__('g-Almarai', 'taj'),
                'g-Tajawal' => esc_html__('g-Tajawal', 'taj'),
                'g-Changa' => esc_html__('g-Changa', 'taj'),
                'g-Lalezar' => esc_html__('g-Lalezar', 'taj'),
                'g-IBM+Plex+Sans+Arabic' => esc_html__('g-IBM+Plex+Sans+Arabic', 'taj'),
                'g-Gulzar' => esc_html__('g-Gulzar', 'taj'),
                'g-Markazi+Text' => esc_html__('g-Markazi+Text', 'taj'),
                'g-Readex+Pro' => esc_html__('g-Readex+Pro', 'taj'),
                'g-Blaka+Hollow' => esc_html__('g-Blaka+Hollow', 'taj'),
                'g-Vazirmatn' => esc_html__('g-Vazirmatn', 'taj'),
                'g-Blaka' => esc_html__('g-Blaka', 'taj'),
                'g-Kufam' => esc_html__('g-Kufam', 'taj'),
                'g-Baloo+Bhaijaan+2' => esc_html__('g-Baloo+Bhaijaan+2', 'taj'),
                'g-Scheherazade+New' => esc_html__('g-Scheherazade+New', 'taj'),
                'g-Vibes' => esc_html__('g-Vibes', 'taj'),
                'g-Qahiri' => esc_html__('g-Qahiri', 'taj'),
                'g-Noto+Kufi+Arabic' => esc_html__('g-Noto+Kufi+Arabic', 'taj'),
                'g-Noto+Naskh+Arabic' => esc_html__('g-Noto+Naskh+Arabic', 'taj'),
                'g-Noto+Sans+Arabic' => esc_html__('g-Noto+Sans+Arabic', 'taj'),
            ),
            'select2'  => array(
                'allowClear' => false,
            ),
            'default'  => 'g-Tajawal',
            'required' => array('taj_website_font_switch','equals','1'),
        ),

    )
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Admin Font', 'taj'),
    'id'     => 'taj_admin_font',
    'subsection' => true,
    'desc'   => esc_html__('Here you can choose the admin font.', 'taj'),
    'icon'   => 'el el-dashboard',
    'fields' => array(
        array(
            'id'       => 'taj_admin_font_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_admin_font_family',
            'type'     => 'select',
            'title'    => esc_html__('Select Font Family', 'taj'),
            // Must provide key => value pairs for select options
            'options'  => array(
                'rabar' => esc_html__('rabar', 'taj'),
                'hanimation' => esc_html__('hanimation', 'taj'),
                'althawra-fikra-bold' => esc_html__('althawra-fikra-bold', 'taj'),
                'althawra-fikra' => esc_html__('althawra-fikra', 'taj'),
                'mehrajan' => esc_html__('mehrajan', 'taj'),
                'cocon-next-arabic' => esc_html__('cocon-next-arabic', 'taj'),
                'kawkab' => esc_html__('kawkab', 'taj'),
                'kawkab-light' => esc_html__('kawkab-light', 'taj'),
                'kawkab-bold' => esc_html__('kawkab-bold', 'taj'),
                'geeza-pro-bold' => esc_html__('geeza-pro-bold', 'taj'),
                'geeza-pro' => esc_html__('geeza-pro', 'taj'),
                'dubai' => esc_html__('dubai', 'taj'),
                'dubai-light' => esc_html__('dubai-light', 'taj'),
                'dubai-medium' => esc_html__('dubai-medium', 'taj'),
                'dubai-bold' => esc_html__('dubai-bold', 'taj'),
                'rsail' => esc_html__('rsail', 'taj'),
                'rsail-bold' => esc_html__('rsail-bold', 'taj'),
                'rsail-light' => esc_html__('rsail-light', 'taj'),
                'arabswell-1' => esc_html__('arabswell-1', 'taj'),
                'rabat' => esc_html__('rabat', 'taj'),
                'sky-bold' => esc_html__('sky-bold', 'taj'),
                'sara' => esc_html__('sara', 'taj'),
                'neckar-bold' => esc_html__('neckar-bold', 'taj'),
                'neckar' => esc_html__('neckar', 'taj'),
                'shahd-bold' => esc_html__('shahd-bold', 'taj'),
                'shahd' => esc_html__('shahd', 'taj'),
                'alhurra' => esc_html__('alhurra', 'taj'),
                'rawy-bold' => esc_html__('rawy-bold', 'taj'),
                'rawy-thin' => esc_html__('rawy-thin', 'taj'),
                'alnaqaa' => esc_html__('alnaqaa', 'taj'),
                'sabgha' => esc_html__('sabgha', 'taj'),
                'vip-hakm-bold' => esc_html__('vip-hakm-bold', 'taj'),
                'vip-hakm-thin' => esc_html__('vip-hakm-thin', 'taj'),
                'vip-hakm' => esc_html__('vip-hakm', 'taj'),
                'smartman' => esc_html__('smartman', 'taj'),
                'zahra-bold' => esc_html__('zahra-bold', 'taj'),
                'zahra' => esc_html__('zahra', 'taj'),
                'sadiyah' => esc_html__('sadiyah', 'taj'),
                'shams' => esc_html__('shams', 'taj'),
                'almushaf' => esc_html__('almushaf', 'taj'),
                'thuluth-decorated' => esc_html__('thuluth-decorated', 'taj'),
                'stoor' => esc_html__('stoor', 'taj'),
                'vip-tim-black' => esc_html__('vip-tim-black', 'taj'),
                'vip-tim-bold' => esc_html__('vip-tim-bold', 'taj'),
                'vip-tim' => esc_html__('vip-tim', 'taj'),
                'vip-tim-light' => esc_html__('vip-tim-light', 'taj'),
                'mirza-medium' => esc_html__('mirza-medium', 'taj'),
                'mirza-bold' => esc_html__('mirza-bold', 'taj'),
                'mirza' => esc_html__('mirza', 'taj'),
                'mada-light' => esc_html__('mada-light', 'taj'),
                'mada-bold' => esc_html__('mada-bold', 'taj'),
                'mada' => esc_html__('mada', 'taj'),
                'lemonada-light' => esc_html__('lemonada-light', 'taj'),
                'lemonada-bold' => esc_html__('lemonada-bold', 'taj'),
                'lemonada' => esc_html__('lemonada', 'taj'),
                'elmessiri-light' => esc_html__('elmessiri-light', 'taj'),
                'elmessiri-bold' => esc_html__('elmessiri-bold', 'taj'),
                'elmessiri' => esc_html__('elmessiri', 'taj'),
                'cairo-bold' => esc_html__('cairo-bold', 'taj'),
                'cairo-extra-light' => esc_html__('cairo-extra-light', 'taj'),
                'cairo-light' => esc_html__('cairo-light', 'taj'),
                'cairo' => esc_html__('cairo', 'taj'),
                'aref-ruqaa' => esc_html__('aref-ruqaa', 'taj'),
                'jazeera-light' => esc_html__('jazeera-light', 'taj'),
                'reem-kufi' => esc_html__('reem-kufi', 'taj'),
                'katibeh' => esc_html__('katibeh', 'taj'),
                'harmattan' => esc_html__('harmattan', 'taj'),
                'jomhuria' => esc_html__('jomhuria', 'taj'),
                'rakkas' => esc_html__('rakkas', 'taj'),
                'tasmeem-med' => esc_html__('tasmeem-med', 'taj'),
                'helal' => esc_html__('helal', 'taj'),
                'homa' => esc_html__('homa', 'taj'),
                'setareh' => esc_html__('setareh', 'taj'),
                'shiraz' => esc_html__('shiraz', 'taj'),
                'omar' => esc_html__('omar', 'taj'),
                'sky' => esc_html__('sky', 'taj'),
                'arwa' => esc_html__('arwa', 'taj'),
                'tachkili' => esc_html__('tachkili', 'taj'),
                'israr-syria' => esc_html__('israr-syria', 'taj'),
                'sukar-black' => esc_html__('sukar-black', 'taj'),
                'sukar-bold' => esc_html__('sukar-bold', 'taj'),
                'sukar' => esc_html__('sukar', 'taj'),
                'bokra' => esc_html__('bokra', 'taj'),
                'bahij' => esc_html__('bahij', 'taj'),
                'motairah-light' => esc_html__('motairah-light', 'taj'),
                'motairah' => esc_html__('motairah', 'taj'),
                'bedayah' => esc_html__('bedayah', 'taj'),
                'tanseek' => esc_html__('tanseek', 'taj'),
                'sheba' => esc_html__('sheba', 'taj'),
                'saudi' => esc_html__('saudi', 'taj'),
                'ishraq' => esc_html__('ishraq', 'taj'),
                'mbc' => esc_html__('mbc', 'taj'),
                'thameen' => esc_html__('thameen', 'taj'),
                'milano' => esc_html__('milano', 'taj'),
                'jordan' => esc_html__('jordan', 'taj'),
                'yassin' => esc_html__('yassin', 'taj'),
                'bein-normal' => esc_html__('bein-normal', 'taj'),
                'bein' => esc_html__('bein', 'taj'),
                'taha-naskh' => esc_html__('taha-naskh', 'taj'),
                'droid-naskh' => esc_html__('droid-naskh', 'taj'),
                'baran' => esc_html__('baran', 'taj'),
                'ghala-bold' => esc_html__('ghala-bold', 'taj'),
                'ghala' => esc_html__('ghala', 'taj'),
                'kamran' => esc_html__('kamran', 'taj'),
                'al-majd' => esc_html__('al-majd', 'taj'),
                'shekari' => esc_html__('shekari', 'taj'),
                'almawadah' => esc_html__('almawadah', 'taj'),
                'kacst-farsi' => esc_html__('kacst-farsi', 'taj'),
                'motken' => esc_html__('motken', 'taj'),
                'insan' => esc_html__('insan', 'taj'),
                'fixed-kufi' => esc_html__('fixed-kufi', 'taj'),
                'esfahan' => esc_html__('esfahan', 'taj'),
                'fantezy' => esc_html__('fantezy', 'taj'),
                'bdavat' => esc_html__('bdavat', 'taj'),
                'Ibtisam' => esc_html__('Ibtisam', 'taj'),
                'shorooq' => esc_html__('shorooq', 'taj'),
                'toyor-aljanah' => esc_html__('toyor-aljanah', 'taj'),
                'spirit-of-doha' => esc_html__('spirit-of-doha', 'taj'),
                'hayah' => esc_html__('hayah', 'taj'),
                'muslimah' => esc_html__('muslimah', 'taj'),
                'alhorr' => esc_html__('alhorr', 'taj'),
                'lamar' => esc_html__('lamar', 'taj'),
                'yaraa-regular' => esc_html__('yaraa-regular', 'taj'),
                'yaraa' => esc_html__('yaraa', 'taj'),
                'aures' => esc_html__('aures', 'taj'),
                'maghrebi' => esc_html__('maghrebi', 'taj'),
                'nawar' => esc_html__('nawar', 'taj'),
                'maidan' => esc_html__('maidan', 'taj'),
                'jannat' => esc_html__('jannat', 'taj'),
                'diana-regular' => esc_html__('diana-regular', 'taj'),
                'diana-light' => esc_html__('diana-light', 'taj'),
                'aqeeq' => esc_html__('aqeeq', 'taj'),
                'alshohadaa' => esc_html__('alshohadaa', 'taj'),
                'alqusair' => esc_html__('alqusair', 'taj'),
                'bon' => esc_html__('bon', 'taj'),
                'asmaa' => esc_html__('asmaa', 'taj'),
                'taqniya' => esc_html__('taqniya', 'taj'),
                'assaf' => esc_html__('assaf', 'taj'),
                'albayan' => esc_html__('albayan', 'taj'),
                'hala' => esc_html__('hala', 'taj'),
                'osama' => esc_html__('osama', 'taj'),
                'baghdad' => esc_html__('baghdad', 'taj'),
                'algeria' => esc_html__('algeria', 'taj'),
                'noorehuda' => esc_html__('noorehuda', 'taj'),
                'themixarab' => esc_html__('themixarab', 'taj'),
                'strick' => esc_html__('strick', 'taj'),
                'rawi' => esc_html__('rawi', 'taj'),
                'jazeera' => esc_html__('jazeera', 'taj'),
                'droid-sans' => esc_html__('droid-sans', 'taj'),
                'lateef' => esc_html__('lateef', 'taj'),
                'Noto-Urdu' => esc_html__('Noto-Urdu', 'taj'),
                'Thabit' => esc_html__('Thabit', 'taj'),
                'b-sepideh' => esc_html__('b-sepideh', 'taj'),
                'boutros-ads' => esc_html__('boutros-ads', 'taj'),
                'stc' => esc_html__('stc', 'taj'),
                'diwanltr' => esc_html__('diwanltr', 'taj'),
                'barabics' => esc_html__('barabics', 'taj'),
                'btehran' => esc_html__('btehran', 'taj'),
                'fanni' => esc_html__('fanni', 'taj'),
                'kufi' => esc_html__('kufi', 'taj'),
                'jooza' => esc_html__('jooza', 'taj'),
                'hama' => esc_html__('hama', 'taj'),
                'DroidKufi-Regular' => esc_html__('DroidKufi-Regular', 'taj'),
                'amiri-quran' => esc_html__('amiri-quran', 'taj'),
                'amiri-slanted' => esc_html__('amiri-slanted', 'taj'),
                'amiri-bold' => esc_html__('amiri-bold', 'taj'),
                'amiri' => esc_html__('amiri', 'taj'),
                'Old-Antic-Bold' => esc_html__('Old-Antic-Bold', 'taj'),
                'farsi-simple-bold' => esc_html__('farsi-simple-bold', 'taj'),
                'diwani-bent' => esc_html__('diwani-bent', 'taj'),
                'ah-moharram-bold' => esc_html__('ah-moharram-bold', 'taj'),
                'b-hamid' => esc_html__('b-hamid', 'taj'),
                'al-gemah-alhoda' => esc_html__('al-gemah-alhoda', 'taj'),
                'old-antic-decorative' => esc_html__('old-antic-decorative', 'taj'),
                'b-compset' => esc_html__('b-compset', 'taj'),
                'decotype-thuluth' => esc_html__('decotype-thuluth', 'taj'),
                'hamada' => esc_html__('hamada', 'taj'),
                'basim-marah' => esc_html__('basim-marah', 'taj'),
                'flat-jooza' => esc_html__('flat-jooza', 'taj'),
                'g-Almarai' => esc_html__('g-Almarai', 'taj'),
                'g-Tajawal' => esc_html__('g-Tajawal', 'taj'),
                'g-Changa' => esc_html__('g-Changa', 'taj'),
                'g-Lalezar' => esc_html__('g-Lalezar', 'taj'),
                'g-IBM+Plex+Sans+Arabic' => esc_html__('g-IBM+Plex+Sans+Arabic', 'taj'),
                'g-Gulzar' => esc_html__('g-Gulzar', 'taj'),
                'g-Markazi+Text' => esc_html__('g-Markazi+Text', 'taj'),
                'g-Readex+Pro' => esc_html__('g-Readex+Pro', 'taj'),
                'g-Blaka+Hollow' => esc_html__('g-Blaka+Hollow', 'taj'),
                'g-Vazirmatn' => esc_html__('g-Vazirmatn', 'taj'),
                'g-Blaka' => esc_html__('g-Blaka', 'taj'),
                'g-Kufam' => esc_html__('g-Kufam', 'taj'),
                'g-Baloo+Bhaijaan+2' => esc_html__('g-Baloo+Bhaijaan+2', 'taj'),
                'g-Scheherazade+New' => esc_html__('g-Scheherazade+New', 'taj'),
                'g-Vibes' => esc_html__('g-Vibes', 'taj'),
                'g-Qahiri' => esc_html__('g-Qahiri', 'taj'),
                'g-Noto+Kufi+Arabic' => esc_html__('g-Noto+Kufi+Arabic', 'taj'),
                'g-Noto+Naskh+Arabic' => esc_html__('g-Noto+Naskh+Arabic', 'taj'),
                'g-Noto+Sans+Arabic' => esc_html__('g-Noto+Sans+Arabic', 'taj'),
            ),
            'select2'  => array(
                'allowClear' => false,
            ),
            'default'  => 'g-Tajawal',
            'required' => array('taj_admin_font_switch','equals','1'),
        ),

    )
);

Redux::set_section($opt_name, $section);



$section = array(
    'title' => __('Blog Settings', 'taj'),
    'id'    => 'blog_settings',
    'desc'  => __('Here you can adjust the blog settings.', 'taj'),
    'icon'  => 'el el-home-alt',
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Blog Page', 'taj'),
    'id'     => 'blog_page',
    'subsection' => true,
    'desc'   => esc_html__('Select where you want to show the sidebar in the Blog Page.', 'taj'),
    'icon'   => 'el el-list-alt',
    'fields' => array(
        array(
            'id'       => 'blog_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Blog Layout', 'taj'),
            'options'  => array(
        '1'      => array(
            'alt'   =>  esc_html__('No Sidebar', 'taj'),
            'title'    => esc_html__('No Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/1col.png'
        ),
        '2'      => array(
            'alt'   => esc_html__('Left Sidebar', 'taj'),
            'title'    => esc_html__('Left Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/2cl.png'
        ),
        '3'      => array(
            'alt'   => esc_html__('Right Sidebar', 'taj'),
            'title'    => esc_html__('Right Sidebar', 'taj'),
            'img'  => ReduxFramework::$_url . 'assets/img/2cr.png'
        )
    ),
    'default' => '2'
        ),
        array(
            'id'       => 'taj_border_radius',
            'type'     => 'slider',
            'title'    => esc_html__('Border Radius', 'taj'),
            'min'      => '0',
            'step'     => '1',
            'max'      => '100',
            'default'  => '3',
            'display_value' => 'text',
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__("This settings will be applied to the theme's  general pages only (eg: blog page and 404 page).", 'taj'),
        ),
        ),
    ),
);

Redux::set_section($opt_name, $section);


$section = array(
    'title'  => esc_html__('Archive & Category Page', 'taj'),
    'id'     => 'archive_page',
    'subsection' => true,
    'desc'   => esc_html__('Select where you want to show the sidebar in the Archive and Category Pages.', 'taj'),
    'icon'   => 'el el-list-alt',
    'fields' => array(
        array(
            'id'       => 'archive_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Archive & Category Layout', 'taj'),
            'options'  => array(
        '1'      => array(
            'alt'   =>  esc_html__('No Sidebar', 'taj'),
            'title'    => esc_html__('No Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/1col.png'
        ),
        '2'      => array(
            'alt'   => esc_html__('Left Sidebar', 'taj'),
            'title'    => esc_html__('Left Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/2cl.png'
        ),
        '3'      => array(
            'alt'   => esc_html__('Right Sidebar', 'taj'),
            'title'    => esc_html__('Right Sidebar', 'taj'),
            'img'  => ReduxFramework::$_url . 'assets/img/2cr.png'
        )
    ),
    'default' => '2'
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Post Page', 'taj'),
    'id'     => 'post_page',
    'subsection' => true,
    'desc'   => esc_html__('Select where you want to show the sidebar in the Post Page.', 'taj'),
    'icon'   => 'el el-pencil',
    'fields' => array(
        array(
            'id'       => 'post_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Post Layout', 'taj'),
            'options'  => array(
        '1'      => array(
            'alt'   =>  esc_html__('No Sidebar', 'taj'),
            'title'    => esc_html__('No Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/1col.png'
        ),
        '2'      => array(
            'alt'   => esc_html__('Left Sidebar', 'taj'),
            'title'    => esc_html__('Left Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/2cl.png'
        ),
        '3'      => array(
            'alt'   => esc_html__('Right Sidebar', 'taj'),
            'title'    => esc_html__('Right Sidebar', 'taj'),
            'img'  => ReduxFramework::$_url . 'assets/img/2cr.png'
        )
    ),
    'default' => '2'
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Search Page', 'taj'),
    'id'     => 'search_page',
    'subsection' => true,
    'desc'   => esc_html__('Select where you want to show the sidebar in the Search Page.', 'taj'),
    'icon'   => 'el el-search',
    'fields' => array(
        array(
            'id'       => 'search_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Search Layout', 'taj'),
            'options'  => array(
        '1'      => array(
            'alt'   =>  esc_html__('No Sidebar', 'taj'),
            'title'    => esc_html__('No Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/1col.png'
        ),
        '2'      => array(
            'alt'   => esc_html__('Left Sidebar', 'taj'),
            'title'    => esc_html__('Left Sidebar', 'taj'),
            'img'   => ReduxFramework::$_url . 'assets/img/2cl.png'
        ),
        '3'      => array(
            'alt'   => esc_html__('Right Sidebar', 'taj'),
            'title'    => esc_html__('Right Sidebar', 'taj'),
            'img'  => ReduxFramework::$_url . 'assets/img/2cr.png'
        )
    ),
    'default' => '2'
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Social Sharing', 'taj'),
    'id'     => 'social_sharing',
    'subsection' => true,
    'desc'   => esc_html__('Select if you want to enable or disable share buttons from appearing at the bottom of the blog.', 'taj'),
    'icon'   => 'el  el-share-alt',
    'fields' => array(
        array(
            'id'       => 'social_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Reading Bar', 'taj'),
    'id'     => 'reading_bar',
    'subsection' => true,
    'desc'   => esc_html__('Here you can adjust the settings of the reading bar.', 'taj'),
    'icon'   => 'el  el-backward',
    'fields' => array(
        array(
            'id'       => 'taj_reading_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
        array(
            'id'       => 'taj_reading_bar_posts_status',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Posts', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_reading_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_reading_bar_pages_status',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Pages', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_reading_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_reading_bar_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Reading Bar Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Top', 'taj'),
                '2' => esc_html__('Bottom', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_reading_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_reading_bar_height',
            'type'     => 'slider',
            'title'    => esc_html__('Reading Bar Height', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '20',
            'default'  => '4',
            'display_value' => 'text',
            'required' => array('taj_reading_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_reading_bar_color',
            'type'     => 'color',
            'title'    => esc_html__('Reading Bar Color', 'taj'),
            'default'  => '#f24835',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_reading_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Related Posts', 'taj'),
    'id'     => 'related_posts',
    'subsection' => true,
    'desc'   => esc_html__('Select if you want to enable or disable related posts from appearing at the bottom of the blog.', 'taj'),
    'icon'   => 'el el-link',
    'fields' => array(
        array(
            'id'       => 'related_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Comments Section', 'taj'),
    'id'     => 'comments_section',
    'subsection' => true,
    'desc'   => esc_html__('Select if you want to enable or disable commects section from appearing at the bottom of the blog.', 'taj'),
    'icon'   => 'el  el-comment-alt',
    'fields' => array(
        array(
            'id'       => 'comments_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
    ),
);

Redux::set_section($opt_name, $section);


$section = array(
    'title'  => esc_html__('Social Media Menu', 'taj'),
    'id'     => 'taj_social_menu',
    'desc'   => esc_html__('Here you can adjust the settings of the social media menu.', 'taj'),
    'icon'   => 'el el-th-list',
    'fields' => array(
        array(
            'id'       => 'taj_social_menu_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_social_menu_open_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Link Open Type', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Open in New Tab', 'taj'),
                '2' => esc_html__('Open in Same Tab', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Menu Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Right', 'taj'),
                '2' => esc_html__('Left', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Menu Shape', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Square', 'taj'),
                '3' => esc_html__('Smooth Borders', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_show_side_space',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Side Space', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_show_bottom_space',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Bottom Space', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_size',
            'type'     => 'slider',
            'title'    => esc_html__('Menu Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '48',
            'display_value' => 'text',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_social_menu_icon_size',
            'type'     => 'slider',
            'title'    => esc_html__('Icon Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '24',
            'display_value' => 'text',
            'required' => array('taj_social_menu_switch','equals','1'),
        ),
  )
);

Redux::set_section($opt_name, $section);


for ($i = 1; $i < 11; $i++) {
    $section = array(
        'title'  => esc_html__('Item ', 'taj') . $i,
        'id'     => 'taj_social_menu' . $i,
        'subsection' => true,
        'desc'   => esc_html__('Enter the item information if you want to use it.', 'taj'),
        'fields' => array(
            array(
                'id'       => 'taj_social_menu_switch' . $i,
                'type'     => 'switch',
                'title'    => esc_html__('Enable/Disable', 'taj'),
                'on' => esc_html__('Enable', 'taj'),
                'off' => esc_html__('Disable', 'taj'),
                'default'  => false,
            ),
            array(
                'id'       => 'taj_social_menu_item_url' . $i,
                'type'     => 'text',
                'title'    => esc_html__('Item URL', 'taj'),
                'attributes'       => array(
                    'type'  => 'url',
                    ),
                'validate' => 'url',
                'default'  => '',
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
            array(
                'id'       => 'taj_social_menu_item_icon' . $i,
                'type'     => 'image_select',
                'title'    => esc_html__('Item Icon', 'taj'),
                'options'  => array(
                        'facebook-f'      => array(
                            'alt'   => 'facebook-f',
                            'img'   => content_url() . '/themes/taj/admin/images/facebook-f.png'
                        ),
                        'x-twitter'      => array(
                            'alt'   => 'x-twitter',
                            'img'   => content_url() . '/themes/taj/admin/images/twitter.png'
                        ),
                        'behance'      => array(
                            'alt'   => 'behance',
                            'img'  => content_url() . '/themes/taj/admin/images/behance.png'
                        ),
                        'discord'      => array(
                            'alt'   => 'discord',
                            'img'  => content_url() . '/themes/taj/admin/images/discord.png'
                        ),
                        'facebook-messenger'      => array(
                            'alt'   => 'facebook-messenger',
                            'img'  => content_url() . '/themes/taj/admin/images/facebook-messenger.png'
                        ),
                        'instagram'      => array(
                            'alt'   => 'instagram',
                            'img'  => content_url() . '/themes/taj/admin/images/instagram.png'
                        ),
                        'linkedin-in'      => array(
                            'alt'   => 'linkedin-in',
                            'img'  => content_url() . '/themes/taj/admin/images/linkedin-in.png'
                        ),
                        'snapchat'      => array(
                            'alt'   => 'snapchat',
                            'img'  => content_url() . '/themes/taj/admin/images/snapchat.png'
                        ),
                        'skype'      => array(
                            'alt'   => 'skype',
                            'img'  => content_url() . '/themes/taj/admin/images/skype.png'
                        ),
                        'telegram'      => array(
                            'alt'   => 'telegram',
                            'img'  => content_url() . '/themes/taj/admin/images/telegram.png'
                        ),
                        'tiktok'      => array(
                            'alt'   => 'tiktok',
                            'img'  => content_url() . '/themes/taj/admin/images/tiktok.png'
                        ),
                        'viber'      => array(
                            'alt'   => 'viber',
                            'img'  => content_url() . '/themes/taj/admin/images/viber.png'
                        ),
                        'whatsapp'      => array(
                            'alt'   => 'whatsapp',
                            'img'  => content_url() . '/themes/taj/admin/images/whatsapp.png'
                        ),
                        'youtube'      => array(
                            'alt'   => 'youtube',
                            'img'  => content_url() . '/themes/taj/admin/images/youtube.png'
                        ),
                        'amazon'      => array(
                            'alt'   => 'amazon',
                            'img'  => content_url() . '/themes/taj/admin/images/amazon.png'
                        ),
                        'app-store'      => array(
                            'alt'   => 'app-store',
                            'img'  => content_url() . '/themes/taj/admin/images/app-store.png'
                        ),
                        'blogger-b'      => array(
                            'alt'   => 'blogger-b',
                            'img'  => content_url() . '/themes/taj/admin/images/blogger-b.png'
                        ),
                        'dropbox'      => array(
                            'alt'   => 'dropbox',
                            'img'  => content_url() . '/themes/taj/admin/images/dropbox.png'
                        ),
                        'github'      => array(
                            'alt'   => 'github',
                            'img'  => content_url() . '/themes/taj/admin/images/github.png'
                        ),
                        'google-drive'      => array(
                            'alt'   => 'google-drive',
                            'img'  => content_url() . '/themes/taj/admin/images/google-drive.png'
                        ),
                        'google-play'      => array(
                            'alt'   => 'google-play',
                            'img'  => content_url() . '/themes/taj/admin/images/google-play.png'
                        ),
                        'google-plus-g'      => array(
                            'alt'   => 'google-plus-g',
                            'img'  => content_url() . '/themes/taj/admin/images/google-plus-g.png'
                        ),
                        'line'      => array(
                            'alt'   => 'line',
                            'img'  => content_url() . '/themes/taj/admin/images/line.png'
                        ),
                        'opencart'      => array(
                            'alt'   => 'opencart',
                            'img'  => content_url() . '/themes/taj/admin/images/opencart.png'
                        ),
                        'pinterest-p'      => array(
                            'alt'   => 'pinterest-p',
                            'img'  => content_url() . '/themes/taj/admin/images/pinterest-p.png'
                        ),
                        'shopify'      => array(
                            'alt'   => 'shopify',
                            'img'  => content_url() . '/themes/taj/admin/images/shopify.png'
                        ),
                        'slack'      => array(
                            'alt'   => 'slack',
                            'img'  => content_url() . '/themes/taj/admin/images/slack.png'
                        ),
                        'twitch'      => array(
                            'alt'   => 'twitch',
                            'img'  => content_url() . '/themes/taj/admin/images/twitch.png'
                        ),
                        'tumblr'      => array(
                            'alt'   => 'tumblr',
                            'img'  => content_url() . '/themes/taj/admin/images/tumblr.png'
                        ),
                    ),
                'default' => 'facebook-f',
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
            array(
                'id'       => 'taj_social_menu_icon_color' . $i,
                'type'     => 'color',
                'title'    => esc_html__('Icon Color', 'taj'),
                'default'  => '#ffffff',
                'transparent' => false,
                'color_alpha' => true,
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
            array(
                'id'       => 'taj_social_menu_icon_color_hover' . $i,
                'type'     => 'color',
                'title'    => esc_html__('Icon Color on Hover', 'taj'),
                'default'  => '#f24835',
                'transparent' => false,
                'color_alpha' => true,
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
            array(
                'id'       => 'taj_social_menu_icon_bg_color' . $i,
                'type'     => 'color',
                'title'    => esc_html__('Icon Background Color', 'taj'),
                'default'  => '#f24835',
                'transparent' => false,
                'color_alpha' => true,
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
            array(
                'id'       => 'taj_social_menu_icon_bg_color_hover' . $i,
                'type'     => 'color',
                'title'    => esc_html__('Icon Background Color on Hover', 'taj'),
                'default'  => '#ffffff',
                'transparent' => false,
                'color_alpha' => true,
                'required' => array('taj_social_menu_switch' . $i,'equals','1'),
            ),
        )
        );
    Redux::set_section($opt_name, $section);
}

$section = array(
    'title'  => esc_html__('Loading Screen', 'taj'),
    'id'     => 'taj_loading_screen',
    'desc'   => esc_html__('Here you can adjust the settings of the loading screen.', 'taj'),
    'icon'   => 'el el-hourglass',
    'fields' => array(
        array(
            'id'       => 'taj_loading_screen_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_loading_screen_icon_type',
            'type'     => 'select',
            'title'    => esc_html__('Icon Type', 'taj'),
            // Must provide key => value pairs for select options
            'options'  => array(
                '1' => esc_html__('Type ', 'taj') . 1,
                '2' => esc_html__('Type ', 'taj') . 2,
                '3' => esc_html__('Type ', 'taj') . 3,
                '4' => esc_html__('Type ', 'taj') . 4,
                '5' => esc_html__('Type ', 'taj') . 5,
                '6' => esc_html__('Type ', 'taj') . 6,
                '7' => esc_html__('Type ', 'taj') . 7,
                '8' => esc_html__('Type ', 'taj') . 8,
                '9' => esc_html__('Type ', 'taj') . 9,
                '10' => esc_html__('Type ', 'taj') . 10,
                '11' => esc_html__('Type ', 'taj') . 11,
                '12' => esc_html__('Type ', 'taj') . 12,
                '13' => esc_html__('Type ', 'taj') . 13,
                '14' => esc_html__('Type ', 'taj') . 14,
                '15' => esc_html__('Type ', 'taj') . 15,
                '16' => esc_html__('Type ', 'taj') . 16,
                '17' => esc_html__('Type ', 'taj') . 17,
                '18' => esc_html__('Type ', 'taj') . 18,
                '19' => esc_html__('Type ', 'taj') . 19,
                '20' => esc_html__('Type ', 'taj') . 20,
                '21' => esc_html__('Type ', 'taj') . 21,
                '22' => esc_html__('Type ', 'taj') . 22,
                '23' => esc_html__('Type ', 'taj') . 23,
                '24' => esc_html__('Type ', 'taj') . 24,
                '25' => esc_html__('Type ', 'taj') . 25,
                '26' => esc_html__('Type ', 'taj') . 26,
                '27' => esc_html__('Type ', 'taj') . 27,
                '28' => esc_html__('Type ', 'taj') . 28,
                '29' => esc_html__('Type ', 'taj') . 29,
                '30' => esc_html__('Type ', 'taj') . 30,
                '31' => esc_html__('Type ', 'taj') . 31,
                '32' => esc_html__('Type ', 'taj') . 32,
                '33' => esc_html__('Type ', 'taj') . 33,
                '34' => esc_html__('Type ', 'taj') . 34,
                '35' => esc_html__('Type ', 'taj') . 35,
                '36' => esc_html__('Type ', 'taj') . 36,
                '37' => esc_html__('Type ', 'taj') . 37,
                '38' => esc_html__('Type ', 'taj') . 38,
                '39' => esc_html__('Type ', 'taj') . 39,
            ),
            'select2'  => array(
                'allowClear' => false,
            ),
            'default'  => '16',
            'required' => array('taj_loading_screen_switch','equals','1'),
                ),
        array(
            'id'       => 'taj_loading_screen_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_loading_screen_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_loading_screen_icon_size',
            'type'     => 'slider',
            'title'    => esc_html__('Icon Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '200',
            'default'  => '80',
            'display_value' => 'text',
            'required' => array('taj_loading_screen_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_loading_screen_icon_primary_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Primary Color', 'taj'),
            'default'  => '#f24936',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_loading_screen_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_loading_screen_icon_secondary_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Secondary Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_loading_screen_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_loading_screen_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Background Color', 'taj'),
            'default'  => '#232323',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_loading_screen_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Call Button', 'taj'),
    'id'     => 'taj_call_button',
    'desc'   => esc_html__('Here you can adjust the settings of the call button.', 'taj'),
    'icon'   => 'el el-phone',
    'fields' => array(
        array(
            'id'       => 'taj_call_button_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_call_button_phone_number',
            'type'     => 'text',
            'title'    => esc_html__('Phone Number', 'taj'),
            'subtitle'    => esc_html__('Enter the country code followed by the mobile number without a + sign.', 'taj'),
            'placeholder' => esc_html__('Phone Number', 'taj'),
            'validate_callback' => 'sanitize_phone_number',
            'hint' => array(
                    'title'   => esc_html__('Example:', 'taj'),
                    'content' => esc_html__('966 987 654 321', 'taj'),
            ),
            'default'  => '966987654321',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Right', 'taj'),
                '2' => esc_html__('Left', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_shape',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Shape', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Square', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_size',
            'type'     => 'slider',
            'title'    => esc_html__('Button Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '60',
            'display_value' => 'text',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_icon_size',
            'type'     => 'slider',
            'title'    => esc_html__('Icon Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '28',
            'display_value' => 'text',
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_icon_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_icon_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color on Hover', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_icon_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color', 'taj'),
            'default'  => '#1195f5',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_call_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_call_button_icon_bg_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color on Hover', 'taj'),
            'default'  => '#006ce0',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_call_button_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Whatsapp Button', 'taj'),
    'id'     => 'taj_whatsapp_button',
    'desc'   => esc_html__('Here you can adjust the settings of the whatsapp button.', 'taj'),
    'icon'   => 'el el-phone-alt',
    'fields' => array(
        array(
            'id'       => 'taj_whatsapp_button_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_whatsapp_button_phone_number',
            'type'     => 'text',
            'title'    => esc_html__('Phone Number', 'taj'),
            'subtitle'    => esc_html__('Enter the country code followed by the mobile number without a + sign.', 'taj'),
            'placeholder' => esc_html__('Phone Number', 'taj'),
            'validate_callback' => 'sanitize_phone_number',
            'hint' => array(
                    'title'   => esc_html__('Example:', 'taj'),
                    'content' => esc_html__('966 987 654 321', 'taj'),
            ),
            'default'  => '966987654321',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_open_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Link Open Type', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Open in New Tab', 'taj'),
                '2' => esc_html__('Open in Same Tab', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Right', 'taj'),
                '2' => esc_html__('Left', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_shape',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Shape', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Square', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_size',
            'type'     => 'slider',
            'title'    => esc_html__('Button Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '60',
            'display_value' => 'text',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_icon_size',
            'type'     => 'slider',
            'title'    => esc_html__('Icon Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '40',
            'display_value' => 'text',
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_icon_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_icon_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color on Hover', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_icon_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color', 'taj'),
            'default'  => '#25d366',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_whatsapp_button_icon_bg_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color on Hover', 'taj'),
            'default'  => '#169c79',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_whatsapp_button_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);


$section = array(
    'title'  => esc_html__('Back to Top Button', 'taj'),
    'id'     => 'taj_back_button',
    'desc'   => esc_html__('Here you can adjust the settings of the back to top button.', 'taj'),
    'icon'   => 'el el-upload',
    'fields' => array(
        array(
            'id'       => 'taj_back_button_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
        array(
            'id'       => 'taj_back_button_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Right', 'taj'),
                '2' => esc_html__('Left', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_shape',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Shape', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Square', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_size',
            'type'     => 'slider',
            'title'    => esc_html__('Button Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '60',
            'display_value' => 'text',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_size',
            'type'     => 'slider',
            'title'    => esc_html__('Icon Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '100',
            'default'  => '40',
            'display_value' => 'text',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_type',
            'type'     => 'image_select',
            'title'    => esc_html__('Icon Type', 'taj'),
            'options'  => array(
                    'angle-up'      => array(
                        'alt'   => 'angle-up',
                        'img'   => content_url() . '/themes/taj/admin/images/angle-up.png'
                    ),
                    'angle-double-up'      => array(
                        'alt'   => 'angle-double-up',
                        'img'   => content_url() . '/themes/taj/admin/images/angle-double-up.png'
                    ),
                    'arrow-circle-up'      => array(
                        'alt'   => 'arrow-circle-up',
                        'img'  => content_url() . '/themes/taj/admin/images/arrow-circle-up.png'
                    ),
                    'arrow-up'      => array(
                        'alt'   => 'arrow-up',
                        'img'   => content_url() . '/themes/taj/admin/images/arrow-up.png'
                    ),
                    'caret-up'      => array(
                        'alt'   => 'caret-up',
                        'img'   => content_url() . '/themes/taj/admin/images/caret-up.png'
                    ),
                    'chevron-circle-up'      => array(
                        'alt'  => 'chevron-circle-up',
                        'img'  => content_url() . '/themes/taj/admin/images/chevron-circle-up.png'
                    ),
                    'chevron-up'      => array(
                        'alt'  => 'chevron-up',
                        'img'  => content_url() . '/themes/taj/admin/images/chevron-up.png'
                    ),
                    'long-arrow-up'      => array(
                        'alt'  => 'long-arrow-up',
                        'img'  => content_url() . '/themes/taj/admin/images/long-arrow-up.png'
                    ),
                ),
            'default' => 'chevron-up',
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color', 'taj'),
            'default'  => '#f24936',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Color on Hover', 'taj'),
            'default'  => '#fdd100',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color', 'taj'),
            'default'  => '#ffffff00',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_back_button_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_back_button_icon_bg_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Icon Background Color on Hover', 'taj'),
            'default'  => '#ffffff00',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_back_button_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);





$section = array(
    'title'  => esc_html__('Banner', 'taj'),
    'id'     => 'taj_banner',
    'desc'   => esc_html__('Here you can adjust the settings of the banner.', 'taj'),
    'icon'   => 'el el-info-circle',
    'fields' => array(
        array(
            'id'       => 'taj_banner_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_banner_text',
            'type'     => 'textarea',
            'title'    => esc_html__('Banner Text', 'taj'),
            'placeholder' => esc_html__('Enter the text you want to display in the banner here..', 'taj'),
            'default'  => '',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_close_button_expiration',
            'type'     => 'slider',
            'title'    => esc_html__('Close Button Expiration', 'taj'),
            'subtitle'    => esc_html__('Close Button Expiration is the number of days after which the banner will appear again.', 'taj'),
            'min'      => '0',
            'step'     => '1',
            'max'      => '365',
            'default'  => '0',
            'display_value' => 'text',
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__('If you want the banner to appear again after pressing the close button set the value of "Close Button Expiration" to 0.', 'taj'),
        ),
        'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Banner Position', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Top', 'taj'),
                '2' => esc_html__('Top - Fixed', 'taj'),
                '3' => esc_html__('Bottom', 'taj'),
                '4' => esc_html__('Bottom - Fixed', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_show_mobile',
            'type'     => 'button_set',
            'title'    => esc_html__('Show on Mobile', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_show_close_button',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Close Button', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_text_font_size',
            'type'     => 'slider',
            'title'    => esc_html__('Text Font Size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '60',
            'default'  => '17',
            'display_value' => 'text',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_close_button_size',
            'type'     => 'slider',
            'title'    => esc_html__('Close Button size', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '60',
            'default'  => '20',
            'display_value' => 'text',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_close_button_shape',
            'type'     => 'image_select',
            'title'    => esc_html__('Close Button Shape', 'taj'),
            'options'  => array(
                    'xmark'      => array(
                        'alt'   => 'xmark',
                        'img'   => content_url() . '/themes/taj/admin/images/xmark.png'
                    ),
                    'circle-xmark'      => array(
                        'alt'   => 'circle-xmark',
                        'img'   => content_url() . '/themes/taj/admin/images/circle-xmark.png'
                    ),
                    'rectangle-xmark'      => array(
                        'alt'   => 'rectangle-xmark',
                        'img'  => content_url() . '/themes/taj/admin/images/rectangle-xmark.png'
                    ),
                ),
            'default' => 'xmark',
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_text_color',
            'type'     => 'color',
            'title'    => esc_html__('Banner Text Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_link_color',
            'type'     => 'color',
            'title'    => esc_html__('Banner Link Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Banner Background Color', 'taj'),
            'default'  => '#f24936',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_banner_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_banner_close_button_color',
            'type'     => 'color',
            'title'    => esc_html__('Banner Close Button Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_banner_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);


$section = array(
    'title'  => esc_html__('Scroll Bar', 'taj'),
    'id'     => 'taj_scroll_bar',
    'desc'   => esc_html__('Here you can adjust the settings of the scroll bar.', 'taj'),
    'icon'   => 'el el-adjust-alt',
    'fields' => array(
        array(
            'id'       => 'taj_scroll_bar_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
        array(
            'id'       => 'taj_scroll_bar_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Scroll Bar Shape', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Square', 'taj'),
                '3' => esc_html__('Smooth Borders', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_scroll_bar_show_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Shadow', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_scroll_bar_width',
            'type'     => 'slider',
            'title'    => esc_html__('Scroll Bar Width', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '20',
            'default'  => '12',
            'display_value' => 'text',
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_scroll_bar_handle_color',
            'type'     => 'color',
            'title'    => esc_html__('Handle Color', 'taj'),
            'default'  => '#8a8c8e',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_scroll_bar_handle_color_hover',
            'type'     => 'color',
            'title'    => esc_html__('Handle Color on Hover', 'taj'),
            'default'  => '#555555',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_scroll_bar_track_color',
            'type'     => 'color',
            'title'    => esc_html__('Track Color', 'taj'),
            'default'  => '#f2f0f0',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_scroll_bar_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Mouse Cursor', 'taj'),
    'id'     => 'taj_mouse_cursor',
    'desc'   => esc_html__('Here you can adjust the settings of the mouse cursor.', 'taj'),
    'icon'   => 'el el-record',
    'fields' => array(
        array(
            'id'       => 'taj_mouse_cursor_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
        ),
        array(
            'id'       => 'taj_mouse_cursor_outer_style',
            'type'     => 'button_set',
            'title'    => esc_html__('Cursor Outer Style', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Circle', 'taj'),
                '2' => esc_html__('Disable', 'taj'),
            ),
            'default'  => '1',
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_hover_effect',
            'type'     => 'button_set',
            'title'    => esc_html__('Hover Effect', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Type ', 'taj') . 1,
                '2' => esc_html__('Type ', 'taj') . 2,
                '3' => esc_html__('Type ', 'taj') . 3,
            ),
            'default'  => '1',
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_hover_item_move',
            'type'     => 'button_set',
            'title'    => esc_html__('Hover Item Move', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Enable', 'taj'),
                '2' => esc_html__('Disable', 'taj'),
            ),
            'default'  => '2',
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__("This feature will apply to the third type only.", 'taj'),
            ),
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_default_cursor',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Default Cursor', 'taj'),
            //Must provide key => value pairs for options
            'options' => array(
                '1' => esc_html__('Show', 'taj'),
                '2' => esc_html__('Hide', 'taj'),
            ),
            'default'  => '2',
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_outer_width',
            'type'     => 'slider',
            'title'    => esc_html__('Cursor Outer Width', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '300',
            'default'  => '30',
            'display_value' => 'text',
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_outer_height',
            'type'     => 'slider',
            'title'    => esc_html__('Cursor Outer Height', 'taj'),
            'min'      => '1',
            'step'     => '1',
            'max'      => '300',
            'default'  => '30',
            'display_value' => 'text',
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_color',
            'type'     => 'color',
            'title'    => esc_html__('Cursor Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_outer_color',
            'type'     => 'color',
            'title'    => esc_html__('Cursor Outer Color', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_color_hover_type2',
            'type'     => 'color',
            'title'    => esc_html__('Cursor Color on Hover (Type 2)', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_color_hover_type3',
            'type'     => 'color',
            'title'    => esc_html__('Cursor Color on Hover (Type 3)', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_mouse_cursor_outer_color_hover_type3',
            'type'     => 'color',
            'title'    => esc_html__('Cursor Outer Color on Hover (Type 3)', 'taj'),
            'default'  => '#ffffff',
            'transparent' => false,
            'color_alpha' => true,
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
        array(
            'id' => 'taj_mouse_cursor_info',
            'type' => 'info',
            'style' => 'info',
            'icon'   => 'el el-info-circle',
            'title' => esc_html__('Note:', 'taj'),
            'desc' => esc_html__('Some colors apply to some styles only.', 'taj'),
            'required' => array('taj_mouse_cursor_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Content Protection', 'taj'),
    'id'     => 'taj_content_protection',
    'desc'   => esc_html__('Here you can adjust the settings of the content protection feature.', 'taj'),
    'icon'   => 'el el-lock-alt',
    'fields' => array(
        array(
            'id'       => 'taj_content_protection_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_content_protection_text_selection',
            'type'     => 'switch',
            'title'    => esc_html__('Prevent Text Selection', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_content_protection_right_click',
            'type'     => 'switch',
            'title'    => esc_html__('Prevent Right Click', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_content_protection_f12',
            'type'     => 'switch',
            'title'    => esc_html__('Prevent Pressing F12', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_content_protection_ctrl_u',
            'type'     => 'switch',
            'title'    => esc_html__('Prevent Pressing Ctrl + U', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_content_protection_ctrl_shift_i',
            'type'     => 'switch',
            'title'    => esc_html__('Prevent Pressing Ctrl + Shift + I', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_content_protection_alert',
            'type'     => 'switch',
            'title'    => esc_html__('Show Alert Message to the User', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'required' => array('taj_content_protection_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Custom Codes', 'taj'),
    'id'     => 'taj_custom_code',
    'desc'   => esc_html__('Enter the codes directly without the corresponding tags such as <style> or <script>. Note: Entering wrong codes may break your site.. Please proceed with caution.', 'taj'),
    'icon'   => 'el el-css',
    'fields' => array(
        array(
            'id'       => 'taj_custom_code_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_custom_code_css',
            'type'     => 'ace_editor',
            'title'    => esc_html__('Global Custom CSS', 'taj'),
            'mode'     => 'css',
            'theme'    => 'chrome',
            'validate' => array(
                'css'
            ),
            'options' => array(
                'minLines' => 12,
                'maxLines' => 30,
                'enableLiveAutocompletion' => true,
            ),
            'default'  => "/*Enter Your Global Custom CSS Code Here*/",
            'required' => array('taj_custom_code_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_custom_code_css_desktop',
            'type'     => 'ace_editor',
            'title'    => esc_html__('Custom CSS for Desktop', 'taj'),
            'mode'     => 'css',
            'theme'    => 'chrome',
            'validate' => array(
                'css'
            ),
            'options' => array(
                'minLines' => 12,
                'maxLines' => 30,
                'enableLiveAutocompletion' => true,
            ),
            'default'  => "/*Enter Your Custom CSS for Desktop Code Here*/",
            'required' => array('taj_custom_code_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_custom_code_css_tablet',
            'type'     => 'ace_editor',
            'title'    => esc_html__('Custom CSS for Tablet', 'taj'),
            'mode'     => 'css',
            'theme'    => 'chrome',
            'validate' => array(
                'css'
            ),
            'options' => array(
                'minLines' => 12,
                'maxLines' => 30,
                'enableLiveAutocompletion' => true,
            ),
            'default'  => "/*Enter Your Custom CSS for Tablet Code Here*/",
            'required' => array('taj_custom_code_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_custom_code_css_mobile',
            'type'     => 'ace_editor',
            'title'    => esc_html__('Custom CSS for Mobile', 'taj'),
            'mode'     => 'css',
            'theme'    => 'chrome',
            'validate' => array(
                'css'
            ),
            'options' => array(
                'minLines' => 12,
                'maxLines' => 30,
                'enableLiveAutocompletion' => true,
            ),
            'default'  => "/*Enter Your Custom CSS for Mobile Code Here*/",
            'required' => array('taj_custom_code_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_custom_code_js',
            'type'     => 'ace_editor',
            'title'    => esc_html__('Global Custom JavaScript', 'taj'),
            'mode'     => 'javascript',
            'theme'    => 'chrome',
            'options' => array(
                'minLines' => 12,
                'maxLines' => 30,
                'enableLiveAutocompletion' => true,
            ),
            'default'  => "/*Enter Your Global Custom JavaScript Code Here*/",
            'required' => array('taj_custom_code_switch','equals','1'),
        ),

    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title'  => esc_html__('Login Page Logo', 'taj'),
    'id'     => 'taj_login_logo',
    'desc'   => esc_html__('Here you can change the logo of the login page.', 'taj'),
    'icon'   => 'el el-picture',
    'fields' => array(
        array(
            'id'       => 'taj_login_logo_switch',
            'type'     => 'switch',
            'title'    => esc_html__('Enable/Disable', 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
        ),
        array(
            'id'       => 'taj_login_logo_image',
            'type'     => 'media',
            'mode'     => 'image',
            'url'      => false,
            'title'    => esc_html__('Logo Image', 'taj'),
            'default'  => array(
            'url' => admin_url() . '/images/wordpress-logo.svg'
        ),
        'required' => array('taj_login_logo_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_login_logo_width',
            'type'     => 'slider',
            'title'    => esc_html__('Logo Width (px)', 'taj'),
            'min'      => '0',
            'step'     => '1',
            'max'      => '800',
            'default'  => '100',
            'display_value' => 'text',
            'required' => array('taj_login_logo_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_login_logo_height',
            'type'     => 'slider',
            'title'    => esc_html__('Logo Height (px)', 'taj'),
            'min'      => '0',
            'step'     => '1',
            'max'      => '800',
            'default'  => '100',
            'display_value' => 'text',
            'required' => array('taj_login_logo_switch','equals','1'),
        ),
    ),
);

Redux::set_section($opt_name, $section);

$section = array(
    'title' => __('Advanced Settings', 'taj'),
    'id'    => 'advanced_settings',
    'desc'  => __('Here you can control the advanced settings of your site.', 'taj'),
    'icon'  => 'el el-cogs',
    'fields'     => array(
        array(
            'id'       => 'taj_duplicate_pages_switch',
            'type'     => 'switch',
            'title'    => esc_html__("Duplicate Pages Feature", 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => true,
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__('This feature will add a button in the list of posts and pages that allows items to be duplicated.', 'taj'),
        ),
        ),
        array(
            'id'       => 'taj_hide_admin_notices_switch',
            'type'     => 'switch',
            'title'    => esc_html__("Hide WP Admin Notices", 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__('This feature will hide all notices generated by some plugins that appear at the top of the WP admin dashboard.. Please note that update notices will also be hidden. Therefore, it is not recommended to enable this feature for websites under development.', 'taj'),
        ),
        ),
        array(
            'id'       => 'taj_wp_maintenance_mode_switch',
            'type'     => 'switch',
            'title'    => esc_html__("Maintenance Mode", 'taj'),
            'on' => esc_html__('Enable', 'taj'),
            'off' => esc_html__('Disable', 'taj'),
            'default'  => false,
            'hint' => array(
                'title'   => esc_html__('Note:', 'taj'),
                'content' => esc_html__('This feature allows you to display a maintenance message to users and temporarily close your site to them while the site is being developed. You can also use this feature as a coming soon mode.', 'taj'),
        ),
        ),
        array(
            'id'       => 'taj_wp_maintenance_mode_title',
            'type'     => 'text',
            'title'    => esc_html__('Message Title', 'taj'),
            'placeholder' => esc_html__('Enter the title of the maintenance message here..', 'taj'),
            'default'  => esc_html__('The site is closed for maintenance', 'taj'),
            'required' => array('taj_wp_maintenance_mode_switch','equals','1'),
        ),
        array(
            'id'       => 'taj_wp_maintenance_mode_text',
            'type'     => 'textarea',
            'title'    => esc_html__('Message Text', 'taj'),
            'placeholder' => esc_html__('Enter the text you want to display in the maintenance message here..', 'taj'),
            'default'  => esc_html__('This site is undergoing maintenance and will be up and running very soon. Please check back later.', 'taj'),
            'required' => array('taj_wp_maintenance_mode_switch','equals','1'),
        ),
    ),

);

Redux::set_section($opt_name, $section);

/*
 * <--- END SECTIONS
 */

/*
 * sanitize phone number entered by the user and make sure it's a valid number
 */

if (! function_exists('sanitize_phone_number')) {
    function sanitize_phone_number($field, $value, $existing_value)
    {
        $error   = false;

        // Do your validation.
        // means that phone number contain letters
        if (!is_numeric($value)) {
            $error = true;
            $field['msg']    = esc_html__('The phone Number should contain only numbers.', 'taj');
            $value = $existing_value;
            $return['error'] = $field;
        }
        // means that phone number contain + sign
        elseif (strpos($value, '+') !== false) {
            $error = true;
            $field['msg']    = esc_html__('The phone number must not contain + sign.', 'taj');
            $value = $existing_value;
            $return['error'] = $field;
        }
        // means that phone number too short
        // country code 2, 3 or 4 digits and phone number 9 digits
        elseif (strlen($value) < 11) {
            $error = true;
            $field['msg']    = esc_html__('The phone number is too short.', 'taj');
            $value = $existing_value;
            $return['error'] = $field;
        }
        // means that phone number too long
        elseif (strlen($value) > 13) {
            $error = true;
            $field['msg']    = esc_html__('The phone number is too long.', 'taj');
            $value = $existing_value;
            $return['error'] = $field;
        }

        // if no error we want the value to be saved
        $return['value'] = $value;

        return $return;
    }
}
