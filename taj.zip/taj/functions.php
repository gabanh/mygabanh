<?php

/**
 * Taj functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Taj
 */

if (!defined('_S_VERSION')) {
    // Replace the version number of the theme on each release.
    define('_S_VERSION', '1.0.1');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function taj_setup()
{
    /*
        * Make theme available for translation.
        * Translations can be filed in the /languages/ directory.
        * If you're building a theme based on Taj, use a find and replace
        * to change 'taj' to the name of your theme in all the template files.
        */
    load_theme_textdomain('taj', get_template_directory() . '/languages');

    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    /*
        * Let WordPress manage the document title.
        * By adding theme support, we declare that this theme does not use a
        * hard-coded <title> tag in the document head, and expect WordPress to
        * provide it for us.
        */
    add_theme_support('title-tag');

    /*
        * Enable support for Post Thumbnails on posts and pages.
        *
        * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
        */
    add_theme_support('post-thumbnails');

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus(
        array(
            'main-menu' => esc_html__('Main Menu', 'taj'),
        )
    );

    /*
        * Switch default core markup for search form, comment form, and comments
        * to output valid HTML5.
        */
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    // Set up the WordPress core custom background feature.
    add_theme_support(
        'custom-background',
        apply_filters(
            'taj_custom_background_args',
            array(
                'default-color' => 'ffffff',
                'default-image' => '',
            )
        )
    );

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');

    /**
     * Add support for core custom logo.
     *
     * @link https://codex.wordpress.org/Theme_Logo
     */
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        )
    );

    /**
     * Add support for Woocommerce Plugin.
     *
     */
    add_theme_support('woocommerce', array(
        //'thumbnail_image_width' => 150,
        //'single_image_width'    => 300,

        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 4,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
    ));

    // Next setting from the WooCommerce 3.0+ enable built-in image slider on the single product page
    add_theme_support('wc-product-gallery-slider');

    // Next setting from the WooCommerce 3.0+ enable built-in image zoom on the single product page
    add_theme_support('wc-product-gallery-zoom');

    // Next setting from the WooCommerce 3.0+ enable built-in image lightbox on the single product page
    add_theme_support('wc-product-gallery-lightbox');

    // Register the Taj Control Panel
    require_once locate_template('/admin/admin-config.php');

    // Get the user options from Taj Control Panel
    require_once locate_template('/inc/user-style.php');

    // Register Taj Elementor Widgets
    require_once locate_template('/inc/elementor-widgets-manager/elementor-widgets-manager.php');

    // Register Taj WooCommerce Configuration
    require_once locate_template('/inc/woocommerce-manager/woocommerce-manager.php');

    if (is_admin()) {
        // Disable Redirecting to the Getting Start Page After Activating Some Plugins
        require_once locate_template('/inc/disable-redirecting.php');

        // Load the Theme Updates Notifications feature
        require_once locate_template('/inc/features/theme-updates.php');
        $update_checker = new ThemeUpdateChecker(
            'taj',
            'https://taj.wp-arabi.com/files/version.json'
        );
        // To manually search for updates, otherwise it happens automatically every 12 hours
        //$update_checker->checkForUpdates();
    }
}
add_action('after_setup_theme', 'taj_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function taj_content_width()
{
    $GLOBALS['content_width'] = apply_filters('taj_content_width', 640);
}
add_action('after_setup_theme', 'taj_content_width', 0);


// Run this funcion ONLY when the theme is activated

function taj_setup_once()
{
    esc_html__('Taj', 'taj');
    esc_html__('Taj Child', 'taj');
    esc_html__('Taj - A Professional WordPress Theme for Educational Websites, Courses, and Quizzes', 'taj');

    // Create "plugins" folder inside "languages" folder if it does not already exist

    // Define the path to the language directory
    $language_dir = WP_LANG_DIR;

    // Define the folder name we want to create within the language directory
    $new_folder_name = 'plugins';

    // Check if the directory doesn't already exist
    if (!is_dir($language_dir . '/' . $new_folder_name)) {
        // Create a new directory within the language directory
        wp_mkdir_p($language_dir . '/' . $new_folder_name);
    }

    // Copy translation files from theme folder to WP languages folder
    $theme_lang_files = array(
        array( 'src' => '/languages/one-click-demo-import-ar.po', 'dest' => '/plugins/one-click-demo-import-ar.po' ),
        array( 'src' => '/languages/one-click-demo-import-ar.mo', 'dest' => '/plugins/one-click-demo-import-ar.mo' ),
        array( 'src' => '/languages/redux-framework-ar.po',       'dest' => '/plugins/redux-framework-ar.po' ),
        array( 'src' => '/languages/redux-framework-ar.mo',       'dest' => '/plugins/redux-framework-ar.mo' ),
        array( 'src' => '/languages/tutor-ar.po',       'dest' => '/plugins/tutor-ar.po' ),
        array( 'src' => '/languages/tutor-ar.mo',       'dest' => '/plugins/tutor-ar.mo' ),
        array( 'src' => '/languages/tutor-ar.l10n.php',       'dest' => '/plugins/tutor-ar.l10n.php' ),
        array( 'src' => '/languages/tutor-ar-4cfaf05fc959d9b8c2a7295db11a0072.json',       'dest' => '/plugins/tutor-ar-4cfaf05fc959d9b8c2a7295db11a0072.json' ),
        array( 'src' => '/languages/tutor-ar-4e74d2b9be4a3b2cf5bfe3c91329b467.json',       'dest' => '/plugins/tutor-ar-4e74d2b9be4a3b2cf5bfe3c91329b467.json' ),
        array( 'src' => '/languages/tutor-ar-9d990bc42b4735a0aa58bf72dde58a4e.json',       'dest' => '/plugins/tutor-ar-9d990bc42b4735a0aa58bf72dde58a4e.json' ),
        array( 'src' => '/languages/tutor-ar-9df240959a3dc9b818f38abda7c87dba.json',       'dest' => '/plugins/tutor-ar-9df240959a3dc9b818f38abda7c87dba.json' ),
        array( 'src' => '/languages/tutor-ar-22ce1461e5db5efad980bedf590d1f3b.json',       'dest' => '/plugins/tutor-ar-22ce1461e5db5efad980bedf590d1f3b.json' ),
        array( 'src' => '/languages/tutor-ar-8808703c1573546ae335ae755ff92789.json',       'dest' => '/plugins/tutor-ar-8808703c1573546ae335ae755ff92789.json' ),
        array( 'src' => '/languages/tutor-ar-bbed70c83b78b1a9880afd7b71a4cc35.json',       'dest' => '/plugins/tutor-ar-bbed70c83b78b1a9880afd7b71a4cc35.json' ),
        array( 'src' => '/languages/tutor-ar-e289b8a26e8042fda203386dcaded9ec.json',       'dest' => '/plugins/tutor-ar-e289b8a26e8042fda203386dcaded9ec.json' ),
        array( 'src' => '/languages/tutor-lms-elementor-addons-ar.po',       'dest' => '/plugins/tutor-lms-elementor-addons-ar.po' ),
        array( 'src' => '/languages/tutor-lms-elementor-addons-ar.mo',       'dest' => '/plugins/tutor-lms-elementor-addons-ar.mo' ),
    );
    foreach ($theme_lang_files as $file) {
        $src  = locate_template($file['src']);
        $dest = $language_dir . $file['dest'];
        if (! file_exists($dest)) {
            copy($src, $dest);
        }
        // compare the modification date of two files for updates
        elseif (filemtime($src) > filemtime($dest)) {
            wp_delete_file($dest);
            copy($src, $dest);
        }
    }
}

add_action('after_switch_theme', 'taj_setup_once');

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function taj_widgets_init()
{
    register_sidebar(
        array(
            'name'          => esc_html__('Sidebar', 'taj'),
            'id'            => 'sidebar-1',
            'description'   => esc_html__('Add widgets here.', 'taj'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action('widgets_init', 'taj_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function taj_scripts()
{
    wp_enqueue_style('taj-style', get_stylesheet_uri(), array(), _S_VERSION);

    wp_enqueue_script('taj-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'taj_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
    require get_template_directory() . '/inc/jetpack.php';
}

/*Taj*/

/*
* Register the Bootstrap Framework
*/

function taj_bootstrap()
{
    /* fontawesome  */
    wp_enqueue_style('fontawesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css');

    /* Bootstrap: Latest compiled JavaScript */
    wp_enqueue_script('bootstrap-js', '//cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js');

    /* Bootstrap: Latest compiled and minified CSS */
    wp_enqueue_style('bootstrap', '//cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css');
}

add_action('wp_enqueue_scripts', 'taj_bootstrap', 30);

/*
* Register the Custom Style of the Admin Wordpress Panel
*/

add_action('admin_enqueue_scripts', 'load_admin_style');

function load_admin_style()
{
    wp_enqueue_style('admin_css', get_template_directory_uri() . '/admin/admin-style.css', false, '1.0.0');
}

// Welcome page and AJAX actions files
if (is_admin()) {
    require_once get_template_directory() . '/inc/welcome-page.php';
    require_once get_template_directory() . '/inc/welcome-ajax-actions.php';
}

// Define Theme Demos
if (is_admin() &&
    ((isset($_GET['page']) && strpos($_GET['page'], 'one-click-demo-import') === 0) ||
     (defined('DOING_AJAX') && DOING_AJAX &&
      isset($_POST['action']) && $_POST['action'] === 'ocdi_import_demo_data') ||
     (defined('DOING_AJAX') && DOING_AJAX &&
      isset($_POST['action']) && $_POST['action'] === 'ocdi_after_import_data'))) {
    require_once locate_template('/inc/demo-import.php');
}

/*
* Register taj year shortcode
*/

function taj_year_shortcode()
{
    $year = date('Y');
    return $year;
}

add_shortcode('taj_year', 'taj_year_shortcode');

/*
* Register taj site link shortcode
*/

function taj_site_link_shortcode()
{
    $site_url = get_site_url();
    // remove http:// and https://
    return str_replace(array('http://', 'https://'), '', $site_url);
}

add_shortcode('taj_site_link', 'taj_site_link_shortcode');

/*
* Enable shortcode execution in menu items
*/

function taj_execute_shortcode_in_menu($items, $args)
{
    $items = do_shortcode($items);
    return $items;
}
add_filter('wp_nav_menu_items', 'taj_execute_shortcode_in_menu', 10, 2);

/*
* Load the files of the features only if the user enable it
*/

function taj_load_features()
{
    global $taj_options;

    /* Reading Bar */
    if ($taj_options['taj_reading_switch']) {
        wp_enqueue_script('taj-reading-bar', get_template_directory_uri() . '/js/taj-reading-bar.js', array(), _S_VERSION, true);
        require_once locate_template('/inc/features/reading-bar.php');
    }

    /* Back to Top Button */
    if ($taj_options['taj_back_button_switch']) {
        wp_enqueue_script('taj-back-button', get_template_directory_uri() . '/js/taj-back-button.js', array(), _S_VERSION, true);
        require_once locate_template('/inc/features/back-button.php');
    }

    /* Call Button */
    if ($taj_options['taj_call_button_switch']) {
        wp_enqueue_script('taj-call-button', get_template_directory_uri() . '/js/taj-call-button.js', array(), _S_VERSION, true);
        require_once locate_template('/inc/features/call-button.php');
    }

    /* Whatsapp Button */
    if ($taj_options['taj_whatsapp_button_switch']) {
        wp_enqueue_script('taj-whatsapp-button', get_template_directory_uri() . '/js/taj-whatsapp-button.js', array(), _S_VERSION, true);
        require_once locate_template('/inc/features/whatsapp-button.php');
    }

    /* Scroll Bar */
    if ($taj_options['taj_scroll_bar_switch']) {
        require_once locate_template('/inc/features/scroll-bar.php');
    }

    /* Mouse Cursor */
    if ($taj_options['taj_mouse_cursor_switch']) {
        wp_enqueue_script('taj-mouse-cursor-cdn', 'https://res.cloudinary.com/veseylab/raw/upload/v1684982764/magicmouse-2.0.0.cdn.min.js', array(), _S_VERSION, true);
        wp_enqueue_script('taj-mouse-cursor', get_template_directory_uri() . '/js/taj-mouse-cursor.js', array(), _S_VERSION, true);
        wp_localize_script('taj-mouse-cursor', 'taj_mouse_cursor_object', array(
                'taj_mouse_cursor_outer_style' => $taj_options['taj_mouse_cursor_outer_style'],
                'taj_mouse_cursor_hover_effect' => $taj_options['taj_mouse_cursor_hover_effect'],
                'taj_mouse_cursor_hover_item_move' => $taj_options['taj_mouse_cursor_hover_item_move'],
                'taj_mouse_cursor_default_cursor' => $taj_options['taj_mouse_cursor_default_cursor'],
                'taj_mouse_cursor_outer_width' => $taj_options['taj_mouse_cursor_outer_width'],
                'taj_mouse_cursor_outer_height' => $taj_options['taj_mouse_cursor_outer_height'],
                ));
        require_once locate_template('/inc/features/mouse-cursor.php');
    }

    /* Custom Code */
    if ($taj_options['taj_custom_code_switch']) {
        require_once locate_template('/inc/features/custom-code.php');
    }

    /* Content Protection */
    if ($taj_options['taj_content_protection_switch']) {
        require_once locate_template('/inc/features/content-protection.php');
    }

    /* Loading Screen */
    if ($taj_options['taj_loading_screen_switch']) {
        wp_enqueue_script('taj-loading-screen', get_template_directory_uri() . '/js/taj-loading-screen.js', array(), _S_VERSION, true);
        wp_localize_script('taj-loading-screen', 'taj_loading_screen_object', array( 'loading_screen_mobile' => $taj_options['taj_loading_screen_show_mobile']));
        require_once locate_template('/inc/features/loading-screen.php');
    }

    /* Banner */
    if ($taj_options['taj_banner_switch']) {

        wp_enqueue_script('taj-banner', get_template_directory_uri() . '/js/taj-banner.js', array(), _S_VERSION, true);
        wp_localize_script('taj-banner', 'taj_banner_object', array(
             'banner_position' => $taj_options['taj_banner_position'],
             'banner_mobile' => $taj_options['taj_banner_show_mobile'],
             'banner_close_button_expiration' => $taj_options['taj_banner_close_button_expiration']
             ));
        require_once locate_template('/inc/features/banner.php');
    }

    /* Social Menu */
    if ($taj_options['taj_social_menu_switch']) {
        wp_enqueue_script('taj-social-menu', get_template_directory_uri() . '/js/taj-social-menu.js', array(), _S_VERSION, true);
        require_once locate_template('/inc/features/social-menu.php');
    }

    /* Website Font */
    if ($taj_options['taj_website_font_switch']) {
        require_once locate_template('/inc/features/website-font.php');
    }
}

add_action('wp_enqueue_scripts', 'taj_load_features');

/*
* Load the Admin Font feature only if the user enable it
*/

function taj_admin_font_feature()
{
    global $taj_options;
    if (isset($taj_options['taj_admin_font_switch']) && $taj_options['taj_admin_font_switch']) {
        require_once locate_template('/inc/features/admin-font.php');
    }
}

add_action('admin_head', 'taj_admin_font_feature');

if (is_admin()) {
    // Load the Duplicate Pages feature only if the user enable it
    require_once locate_template('/inc/features/duplicate-pages.php');

    // Load the Hide Admin Notices feature only if the user enable it
    require_once locate_template('/inc/features/hide-admin-notices.php');
}

// Load the Login Logo feature only if the user enable it
require_once locate_template('/inc/features/login-logo.php');

// Load the WordPress Maintenance Mode feature only if the user enable it
require_once locate_template('/inc/features/maintenance-mode.php');

// Load the js file to wp admin that responsible for autocomplete feature for the ace editor
function taj_load_admin_scripts($hook)
{
    // load the file only in theme options page
    $currentScreen = get_current_screen();
    if ($currentScreen->base == 'toplevel_page_taj_options') {
        wp_enqueue_script('ext_language_tools', get_template_directory_uri() . '/js/ext-language_tools.js', array(), _S_VERSION, true);
    }
}

add_action('admin_enqueue_scripts', 'taj_load_admin_scripts');

/**
 * Filter the except length to 20 words.
 *
 * @param int $length Excerpt length.
 * @return int (Maybe) modified excerpt length.
 */
function taj_custom_excerpt_length($length)
{
    return 21;
}
add_filter('excerpt_length', 'taj_custom_excerpt_length', 999);

/**
 * Filter the excerpt "read more" string.
 *
 * @param string $more "Read more" excerpt string.
 * @return string (Maybe) modified "read more" excerpt string.
 */
function taj_excerpt_more($more)
{
    return '..';
}
add_filter('excerpt_more', 'taj_excerpt_more');

// Conditionally removes specific menu items based on the user's login status (guest or logged-in)
function taj_filter_nav_menu_items_by_login_status($items, $args)
{
    foreach ($items as $key => $item) {
        // Hide the control panel button (taj-user-button) for guest users
        if (in_array('taj-user-button', $item->classes) && !is_user_logged_in()) {
            unset($items[$key]);
        }
        // Hide the login/register button (taj-guest-button) for registered users
        if (in_array('taj-guest-button', $item->classes) && is_user_logged_in()) {
            unset($items[$key]);
        }
    }
    return $items;
}

add_filter('wp_nav_menu_objects', 'taj_filter_nav_menu_items_by_login_status', 10, 2);

// Hide the WordPress admin bar for Tutor LMS instructors
add_filter('show_admin_bar', function ($show) {
    if (current_user_can('tutor_instructor') && ! current_user_can('administrator')) {
        return false;
    }
    return $show;
});

// Prevent Tutor LMS instructors from accessing the wp-admin dashboard
add_action('admin_init', function () {
    if (
        is_admin() &&
        current_user_can('tutor_instructor') &&
        ! current_user_can('administrator') &&
        ! (defined('DOING_AJAX') && DOING_AJAX)
    ) {
        $allowed_pages = [
            'create-course'];

        $current_page = isset($_GET['page']) ? $_GET['page'] : '';

        if (! in_array($current_page, $allowed_pages)) {
            wp_redirect(home_url());
            exit;
        }
    }
});

// Add Custom admin css for Tutor LMS instructors
function custom_admin_css_for_instructors()
{
    if (current_user_can('tutor_instructor') && ! current_user_can('administrator')) {
        echo '<style>
        body {
            margin-top: -32px !important;
        }
        #wpadminbar {
            display:none;
        }
        #tutor-course-builder > div > div:nth-child(2) > div > div:nth-child(2) > div:last-child {
            display:none;
        }
        </style>';
    }
}
add_action('admin_head', 'custom_admin_css_for_instructors');
