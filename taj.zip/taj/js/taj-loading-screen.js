
/*
* Loading Screen
*/

// get a reference to our loading screen
var tajLoadingScreen = document.querySelector(".tajLoadingScreen");

// determine the status of the loading screen based on the page ready state
if (tajLoadingScreen) {
	document.onreadystatechange = function () {
		// if the user want to hide loading screen in mobile
		if (taj_loading_screen_object.loading_screen_mobile == 2 && screen.width <= 480) {
			tajLoadingScreen.style.display = "none";
		} else {
			if (document.readyState !== "complete") {
				// show wp admin bar always
				document.getElementById("wpadminbar").style.visibility = "visible";
				document.querySelector("body").style.visibility = "hidden";
				tajLoadingScreen.style.visibility = "visible";
			} else {
				tajLoadingScreen.classList.add('hidetajLoadingScreen');
				//set the display to none after the fade out animation ends
				setTimeout(function () {
					tajLoadingScreen.style.display = "none";
				}, 800);
				// enable the scoll bar of html element again (we hide it using css)
				document.documentElement.style.overflow = "auto";
				document.querySelector("body").style.visibility = "visible";
			}
		}

	};
}
