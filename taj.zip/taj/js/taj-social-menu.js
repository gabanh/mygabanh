
/*
* Social Menu
*/

// get a reference to our social menu
var tajSocialMenu = document.querySelector(".tajSocialMenu");

window.addEventListener("load", function (event) {

    // show the menu after 1 seconds of page loads
    setTimeout(function () {
        if (tajSocialMenu != null) {
            tajSocialMenu.classList.add("showtajSocialMenu");
        }
    }, 1000);
}, false);