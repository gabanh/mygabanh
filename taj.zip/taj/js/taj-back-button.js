
/*
* Back to top Button
*/

// get a reference to our button
var scrollToTopBtn = document.querySelector(".tajScrollToTopBtn");

// fire the corresponding function based on event type (scroll/click)
if (scrollToTopBtn != null) {
	document.addEventListener("scroll", tajHandleScroll);
	scrollToTopBtn.addEventListener("click", tajScrollToTop);
}

function tajHandleScroll() {
	var scrollableHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;

	// The distance at which the button appears
	var GOLDEN_RATIO = 0.1;

	if ((document.documentElement.scrollTop / scrollableHeight) > GOLDEN_RATIO) {
		//show button
		if (!scrollToTopBtn.classList.contains("showScrollBtn"))
			scrollToTopBtn.classList.add("showScrollBtn")
	} else {
		//hide button
		if (scrollToTopBtn.classList.contains("showScrollBtn"))
			scrollToTopBtn.classList.remove("showScrollBtn")
	}
}

function tajScrollToTop() {
	window.scrollTo({
		top: 0,
		behavior: "smooth"
	});
}