
/*
* Mouse Cursor
*/

// Get all <a> elements using document.querySelectorAll()
var links = document.querySelectorAll('a');

// Iterate through each <a> element and adding the classes required for magic mouse to work
links.forEach(function (link) {
    link.classList.add('magic-hover', 'magic-hover__square');
});

var taj_mouse_cursor_outer_style;
var taj_mouse_cursor_hover_effect;
var taj_mouse_cursor_hover_item_move;
var taj_mouse_cursor_default_cursor;

if (taj_mouse_cursor_object.taj_mouse_cursor_outer_style == 1)
    taj_mouse_cursor_outer_style = 'circle';
else
    taj_mouse_cursor_outer_style = 'disable';

    if (taj_mouse_cursor_object.taj_mouse_cursor_hover_effect == 1)
    taj_mouse_cursor_hover_effect = 'pointer-overlay';
else if (taj_mouse_cursor_object.taj_mouse_cursor_hover_effect == 2)
    taj_mouse_cursor_hover_effect = 'pointer-blur';
else
    taj_mouse_cursor_hover_effect = 'circle-move';

if (taj_mouse_cursor_object.taj_mouse_cursor_hover_item_move == 1)
    taj_mouse_cursor_hover_item_move = true;
else
    taj_mouse_cursor_hover_item_move = false;

if (taj_mouse_cursor_object.taj_mouse_cursor_default_cursor == 1)
    taj_mouse_cursor_default_cursor = true;
else
    taj_mouse_cursor_default_cursor = false;


options = {
    "outerStyle": taj_mouse_cursor_outer_style,
    "hoverEffect": taj_mouse_cursor_hover_effect,
    "hoverItemMove": taj_mouse_cursor_hover_item_move,
    "defaultCursor": taj_mouse_cursor_default_cursor,
    "outerWidth": parseInt(taj_mouse_cursor_object.taj_mouse_cursor_outer_width),
    "outerHeight": parseInt(taj_mouse_cursor_object.taj_mouse_cursor_outer_height)
};
magicMouse(options);
