
/*
* Banner
*/

// get a reference to our banner
var tajBanner = document.getElementById("tajBanner");

window.addEventListener("load",function(event) {

	// on page loads check for the banner cookie and the close button expiration
	let tajBannerCookie = getCookie("tajBanner");

	// update the tajBanner cookie if the admin changed the number of days value
	// AND if the days is zero
	if (tajBannerCookie != taj_banner_object.banner_close_button_expiration && taj_banner_object.banner_close_button_expiration == 0) {
		setCookie("tajBanner", taj_banner_object.banner_close_button_expiration, taj_banner_object.banner_close_button_expiration);
		tajBannerCookie = taj_banner_object.banner_close_button_expiration;
	}

	//means there is no active cookie value for close button expiration so show the banner (or the value is zero days)
	if ((tajBannerCookie == "" || tajBannerCookie == 0) && tajBanner) {

		tajBanner.style.display = 'block';

		// set the position of the banner correctly
		if (taj_banner_object.banner_position == 1) {
			document.body.insertAdjacentElement('afterbegin', tajBanner);
			tajBanner.style.position = 'relative';
			tajBanner.style.top = '0px';
			tajBanner.style.bottom = 'auto';
		}
		else if (taj_banner_object.banner_position == 2) {
			document.body.style.marginTop = '62px';
			tajBanner.style.position = 'fixed';
			tajBanner.style.top = '0px';
			tajBanner.style.bottom = 'auto';
			// set margin top to the banner if user logged in to make the banner under the wp admin bar
			if (document.body.classList.contains('logged-in')) {
				tajBanner.style.marginTop = '32px';
			}
		}
		else if (taj_banner_object.banner_position == 3) {
			tajBanner.style.position = 'absolute';
			tajBanner.style.top = 'auto';
			tajBanner.style.bottom = 'auto';
		}
		else if (taj_banner_object.banner_position == 4) {
			document.body.style.marginBottom = '62px';
			tajBanner.style.position = 'fixed';
			tajBanner.style.top = 'auto';
			tajBanner.style.bottom = '0px';
		}

		// remove the margin from the body element on mobile if we do not want to show the banner on mobile AND remove the banner also
		if (taj_banner_object.banner_mobile == 2 && screen.width <= 480) {
			document.body.style.margin = '0px';
			tajBanner.style.display = 'none';
		}
	}
	// means there is an active cookie value for close button expiration so do not show the banner (and the value is NOT zero days)
	else {
		if (tajBanner) {
			tajBanner.style.display = 'none';
		}

	}

},false);

// function to close the banner when user click on the close button
function tajBannerClose() {
	// remove the margin that we added from the body element
	document.body.style.margin = '0px';
	// set or update the tajBanner cookie (name/value/days)
	setCookie("tajBanner", taj_banner_object.banner_close_button_expiration, taj_banner_object.banner_close_button_expiration);
	// hide the banner
	fadeOut(tajBanner);
}

// fade out
function fadeOut(el) {
	el.style.opacity = 1;

	(function fade() {
		if ((el.style.opacity -= .1) < 0) {
			el.style.display = 'none';
		} else {
			requestAnimationFrame(fade);
		}
	})();
}

/* Function to Set a Cookie
* cname = name of the cookie
* cvalue = value of the cookie
* exdays = number of days until the cookie should expire
*/
function setCookie(cname, cvalue, exdays) {
	const d = new Date();
	d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
	let expires = "expires=" + d.toUTCString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// Function to Get a Cookie
function getCookie(cname) {
	let name = cname + "=";
	let decodedCookie = decodeURIComponent(document.cookie);
	let ca = decodedCookie.split(';');
	for (let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}
