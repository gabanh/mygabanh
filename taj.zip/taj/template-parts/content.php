<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Taj
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php taj_post_thumbnail(); ?>

	<header class="entry-header">
		<?php
		if ( is_singular() ) :
			// we do not want to show the title here because we have the Page Title (Taj) elementor widget that will show the correct title
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				taj_posted_on();
				taj_posted_by();
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->


	<div class="entry-content">
		<?php
		/* Show full post content only inside single post pages */
			/* Other pages such as archive & category & author pages we must show only the excerpt of content*/
			if( !is_singular())
			{
				the_excerpt();
			}

			else{
		the_content(
			sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'taj' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				wp_kses_post( get_the_title() )
			)
		);

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'taj' ),
				'after'  => '</div>',
			)
		);
	}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php taj_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
