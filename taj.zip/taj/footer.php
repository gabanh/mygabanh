<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Taj
 */
/* There nothing to do here because our theme uses Elementor to build the Footer Section */
?>

<footer id="colophon" class="site-footer text-center py-4 px-3">
		<div class="site-info">

	
			<p> <?php echo esc_html__( 'Please assign a footer using Elementor Page Builder ', 'taj' ); ?> </P>

		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
