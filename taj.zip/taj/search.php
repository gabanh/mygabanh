<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Taj
 */

get_header();

global $taj_options;

if ($taj_options['taj_page_titles_switch']) {
    echo do_shortcode($taj_options['taj_page_titles_shortcode']);
}


?>
<div class="container taj-wrap">


    <div class="row">

     <!-- Right Sidebar -->
 <?php if ($taj_options['search_layout'] == 3): ?>
        <div class="col-md-3">
            <?php
            get_sidebar();
     ?>
        </div>
        <?php endif; ?>


   <!-- No Sidebar -->
   <?php if ($taj_options['search_layout'] == 1): ?>
        <div class="col-md-12">

            <!-- Right or Left Sidebar -->
            <?php else: ?>
            <div class="col-md-9">
                <?php endif; ?>

            <main id="primary" class="site-main">

                <?php if (have_posts()) :

                    /* Start the Loop */
                    while (have_posts()) :
                        the_post();

                        /**
                         * Run the loop for the search to output the results.
                         * If you want to overload this in a child theme then include a file
                         * called content-search.php and that will be used instead.
                         */
                        get_template_part('template-parts/content', 'search');

                    endwhile;

                    the_posts_navigation();

                else :

                    get_template_part('template-parts/content', 'none');

                endif;
?>

            </main><!-- #main -->

        </div>



       <!-- Left Sidebar -->
	   <?php if ($taj_options['search_layout'] == 2): ?>
            <div class="col-md-3">
                <?php
    get_sidebar();
	       ?>
            </div>
            <?php endif; ?>

    </div>

</div>

<?php
get_footer();
