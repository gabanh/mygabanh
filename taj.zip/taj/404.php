<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Taj
 */

get_header();

global $taj_options;

if ($taj_options['taj_page_titles_switch']) {
    echo do_shortcode($taj_options['taj_page_titles_shortcode']);
}

?>

<main id="primary" class="site-main taj-wrap">

    <section class="error-404 not-found text-center">
        <header class="page-header">
            <h2>404</h2>
        </header><!-- .page-header -->

        <div class="page-content">
            <p><?php esc_html_e('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'taj'); ?>
            </p>

            <?php
                    get_search_form();
?>


        </div><!-- .page-content -->
    </section><!-- .error-404 -->

</main><!-- #main -->

<?php
get_footer();
