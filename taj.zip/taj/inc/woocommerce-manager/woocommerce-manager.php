<?php
/**
 * Register Taj WooCommerce Configuration
 *
 * @since 2.0.0
 * @package Taj
 */

// Remove the sidebar from shop page + single product page
// Override templates/global/sidebar.php
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

// Edit default woocommerce wrapper (start + end)
// Override templates/global/wrapper-start.php
// Override templates/global/wrapper-end.php
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

function taj_wrapper_start()
{
    // Show the correct page title
    global $taj_options;
    if ($taj_options['taj_page_titles_switch']) {
        echo do_shortcode($taj_options['taj_page_titles_shortcode']);
    }
    echo '<div class="container taj-wrap"><div id="primary" class="content-area"><main id="main" class="site-main" role="main">';
}

function taj_wrapper_end()
{
    echo '</main></div></div>';
}

add_action('woocommerce_before_main_content', 'taj_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'taj_wrapper_end', 10);

// Remove the title from the single product page because we have the Page Title (Taj) elementor widget that will show the correct title
// Override templates/content-single-product.php
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);

// Remove the title from the shop page because we have the Page Title (Taj) elementor widget that will show the correct title
function taj_hide_shop_page_title()
{
    if (is_shop()) {
        return false;
    }
}

add_filter('woocommerce_show_page_title', 'taj_hide_shop_page_title');

// Change the Number of WooCommerce Products Displayed Per Page
function taj_loop_shop_per_page($products)
{
    $products = 12;
    return $products;
}
add_filter('loop_shop_per_page', 'taj_loop_shop_per_page', 20);
