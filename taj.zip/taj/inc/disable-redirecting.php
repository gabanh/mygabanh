<?php

/**
 * Disable Redirecting to the Getting Start Page After Activating Some Plugins
 *
 * @package Taj
 */


// Disable Redirecting to the Getting Start Page After Activating Elementor Plugin
add_action('admin_init', function () {
    if (did_action('elementor/loaded')) {
        remove_action('admin_init', [ \Elementor\Plugin::$instance->admin, 'maybe_redirect_to_getting_started' ]);
    }
}, 1);

// Disable Redirecting to the Getting Start Page After Activating WooCommerce Plugin
add_filter('woocommerce_enable_setup_wizard', '__return_false');

// Disable Redirecting to the Getting Start Page After Activating Ultimate Addons for Elementor Plugin
update_option( 'hfe_start_onboarding', false );

// Disable Redirecting to the Getting Start Page After Activating ElementsKit Plugin
add_action( 'admin_init', function() {
    if ( ! get_option( 'elements_kit_onboard_status' ) ) {
        update_option( 'elements_kit_onboard_status', 'onboarded' );
    }
} );

// Disable Redirecting to the Getting Start Page After Activating Tutor LMS Plugin
add_action( 'admin_init', function() {
    if ( is_admin() && isset( $_GET['page'] ) && $_GET['page'] === 'tutor-setup' ) {
        wp_safe_redirect( admin_url() );
        exit;
    }
}, 1 );
