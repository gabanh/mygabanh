<?php

/**
 * Taj Footer Text widget
 *
 */

use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

class Taj_Footer_Text extends Widget_Base
{
    /**
     * Retrieve the widget name.
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'taj-footer-text';
    }

    /**
     * Retrieve the widget title.
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Footer Text (Taj)', 'taj');
    }

    /**
     * Retrieve the widget icon.
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-text';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'basic' ];
    }

    /**
     * Register Page Title controls.
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'section_general_fields',
            [
                'label' => __('Footer Text', 'taj'),
            ]
        );

        $this->add_control(
            'footer_text_note',
            [
                'type'            => Controls_Manager::RAW_HTML,
                /* translators: %1$s doc link */
                'raw'             => sprintf(__('<b>Note:</b> The current year will be generated automatically by [taj_year].', 'taj')),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-success',
            ]
        );

        $this->add_control(
            'footer_text_content',
            [
                'label' => esc_html__('Enter the text you want to display in the footer here.', 'taj'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => '&copy; ' . '[taj_year]',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_typography',
            [
                'label' => __('Footer Text', 'taj'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'alignment',
            [
                'type' => Controls_Manager::CHOOSE,
                'label' => esc_html__('Alignment', 'elementor'),
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'elementor'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'elementor'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'elementor'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors'          => [
                    '{{WRAPPER}} p' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} p',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => __('Text Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} p' => 'color: {{VALUE}};'],
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'title_shadow',
                'selector' => '{{WRAPPER}} p',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render footer text widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        
		echo do_shortcode($settings['footer_text_content']);
        
    }

    /**
     * Render footer text output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @access protected
     */
    protected function content_template()
    {}
}


