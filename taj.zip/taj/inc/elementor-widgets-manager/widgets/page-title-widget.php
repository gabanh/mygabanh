<?php

/**
 * Taj Page Title widget
 *
 */

use Elementor\Controls_Manager;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

class Taj_Page_Title extends Widget_Base
{
    /**
     * Retrieve the widget name.
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'taj-page-title';
    }

    /**
     * Retrieve the widget title.
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Page Title (Taj)', 'taj');
    }

    /**
     * Retrieve the widget icon.
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-archive-title';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return [ 'basic' ];
    }

    /**
     * Register Page Title controls.
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->start_controls_section(
            'section_general_fields',
            [
                'label' => __('Page Title', 'taj'),
            ]
        );

        $this->add_control(
            'archive_title_note',
            [
                'type'            => Controls_Manager::RAW_HTML,
                /* translators: %1$s doc link */
                'raw'             => sprintf(__('<b>Note:</b> The page title will be generated automatically.', 'taj')),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-success',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_typography',
            [
                'label' => __('Page Title', 'taj'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'alignment',
            [
                'type' => Controls_Manager::CHOOSE,
                'label' => esc_html__('Alignment', 'elementor'),
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'elementor'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'elementor'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'elementor'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors'          => [
                    '{{WRAPPER}} .elementor-heading-title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => __('Text Color', 'elementor'),
                'type'      => Controls_Manager::COLOR,
                'global'    => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'color: {{VALUE}};'],
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'title_shadow',
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->end_controls_section();
    }


    /**
     * Render page title widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        echo '<h1 class="elementor-heading-title elementor-size-default">';
        $this->taj_title();
        echo '</h1>';
    }

    /**
     * Render page title output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @access protected
     */
    protected function content_template()
    {
        ?>
		<h1 class="elementor-heading-title elementor-size-default">
		<?php
        $this->taj_title();
        ?>
		</h1>
		<?php
    }

    /**
     * Get Page titles for all types
     */
    public function taj_title()
    {
        if (is_home()) {
            if (get_option('page_for_posts', true)) {
                echo get_the_title(get_option('page_for_posts', true));
            } elseif (strpos($_SERVER['REQUEST_URI'], '/profile/') !== false) {
                // Tutor LMS student & instructor profile page
                echo wp_get_document_title();
            } else {
                _e('Latest Posts', 'taj');
            }
        } elseif (is_archive()) {
            $term = get_term_by('slug', get_query_var('term'), get_query_var('taxonomy'));
            if ($term) {
                echo $term->name;
            } elseif (is_post_type_archive()) {
                echo get_queried_object()->labels->name;
            } elseif (is_day()) {
                printf(__('Daily Archives: %s', 'taj'), get_the_date());
            } elseif (is_month()) {
                printf(__('Monthly Archives: %s', 'taj'), get_the_date('F Y'));
            } elseif (is_year()) {
                printf(__('Yearly Archives: %s', 'taj'), get_the_date('Y'));
            } elseif (is_author()) {
                $author = get_queried_object();
                printf(__('Author Archives: %s', 'taj'), $author->display_name);
            } else {
                single_cat_title();
            }
        } elseif (is_search()) {
            printf(__('Search Results for: %s', 'taj'), get_search_query());
        } elseif (is_404()) {
            _e('Page Not Found', 'taj');
        } else {
            the_title();
        }
    }
}
