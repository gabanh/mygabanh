<?php
/**
 * Register Taj Elementor Widgets.
 *
 * Include widget file and register widget class.
 *
 * @since 2.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 * @package Taj
 */

function register_taj_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/breadcrumb-widget.php' );
	require_once( __DIR__ . '/widgets/page-title-widget.php' );
	require_once( __DIR__ . '/widgets/footer-text-widget.php' );

	$widgets_manager->register( new \Taj_Breadcrumb() );
	$widgets_manager->register( new \Taj_Page_Title() );
	$widgets_manager->register( new \Taj_Footer_Text() );

}
add_action( 'elementor/widgets/register', 'register_taj_widget' );