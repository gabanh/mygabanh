<?php
/**
 * Get the user options from Taj Control Panel
 *
 * @package Taj
 */

add_action( 'wp_head', 'taj_stylesheet' );

function taj_stylesheet() {

	// Global Options
	global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_primary_color = $taj_options['taj_primary_color'];
    $taj_secondary_color = $taj_options['taj_secondary_color'];
    $taj_hover_color = $taj_options['taj_hover_color'];
    $taj_selection_color = $taj_options['taj_selection_color'];
    $taj_border_radius = $taj_options['taj_border_radius'];
    $taj_default_background_color = $taj_options['taj_default_background_color'];
    $taj_widget_background_color = $taj_options['taj_widget_background_color'];

    ?>

    <style>

:root {
	--taj-primary-color: <?php echo esc_attr($taj_primary_color) ?>;
	--taj-secondary-color: <?php echo esc_attr($taj_secondary_color) ?>;
	--taj-hover-color: <?php echo esc_attr($taj_hover_color) ?>;
    --taj-selection-color: <?php echo esc_attr($taj_selection_color) ?>;
    --taj-border-radius: <?php echo esc_attr($taj_border_radius) ?>px;
    --taj-widget-background-color: <?php echo esc_attr($taj_widget_background_color) ?>;
    --taj-default-background-color: <?php echo esc_attr($taj_default_background_color) ?>;
}

    </style>

<?php
}