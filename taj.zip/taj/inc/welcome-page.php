<?php
/**
 * Add and manage the theme welcome page
 * @package Taj
 */

// Add Welcome Page to Appearance Menu in WordPress Dashboard
function taj_add_welcome_page()
{
    add_theme_page(
        esc_html__('Welcome to the Taj Theme', 'taj'),
        esc_html__('Startup Wizard - Taj', 'taj'),
        'manage_options',
        'taj-welcome',
        'taj_welcome_page_callback'
    );
}
add_action('admin_menu', 'taj_add_welcome_page');

// Redirect to the welcome page after activating the theme
function taj_redirect_after_activation()
{
    if (is_admin() && isset($_GET['activated'])) {
        wp_redirect(admin_url('themes.php?page=taj-welcome'));
        exit;
    }
}
add_action('after_switch_theme', 'taj_redirect_after_activation');

// Welcome page content display function
function taj_welcome_page_callback()
{

    // Check the status of the One Click Demo Import plugin
    $plugin_file      = 'one-click-demo-import/one-click-demo-import.php';
    $plugin_installed = file_exists(WP_PLUGIN_DIR . '/' . $plugin_file);
    $plugin_active    = $plugin_installed && is_plugin_active($plugin_file);

    // Check the status of the child theme
    $child_theme_slug    = 'taj-child';
    $theme_root          = get_theme_root();
    $child_theme_active  = (wp_get_theme()->get_stylesheet() === $child_theme_slug);

    // Generate nonces for each process
    $plugin_nonce = wp_create_nonce('taj_install_plugin');
    $child_nonce  = wp_create_nonce('taj_install_child_theme');
    ?>

    <div class="wrap" style="text-align: center;">
    <h1 style="margin-top: 15px; font-family: tahoma; font-weight: normal;"><?php esc_html_e('Welcome to the Taj Theme', 'taj'); ?></h1>

    <img 
         src="https://taj.wp-arabi.com/files/welcome.png" 
         style="max-width: 50%; height: auto; margin: 15px 0;" 
    />
    
    <p><?php esc_html_e('Thank you for choosing the Taj theme. You can now start using it quickly and easily by first installing and activating the child theme, followed by importing theme templates.', 'taj'); ?></p>
    
    <div style="display: flex; justify-content: center; gap: 20px; margin-top: 20px;">
        
        <?php if ($child_theme_active) : ?>
            <button 
                id="child-theme-action" 
                class="button" 
                disabled 
                style="font-size: 1.2em; padding: 10px 20px;"
            >
                &#10004; <?php esc_html_e('Child Theme is Enabled', 'taj'); ?>
            </button>
        <?php else : ?>
            <button 
                id="child-theme-action" 
                class="button" 
                data-nonce="<?php echo esc_attr($child_nonce); ?>" 
                style="font-size: 1.2em; padding: 10px 20px;"
            >
                <?php esc_html_e('Install and Activate the Child Theme', 'taj'); ?>
            </button>
        <?php endif; ?>
        
        <?php if ($plugin_active) : ?>
            <a 
                id="plugin-action" 
                class="button button-primary" 
                href="<?php echo admin_url('admin.php?page=one-click-demo-import'); ?>" 
                style="font-size: 1.2em; padding: 10px 20px;"
            >
                <?php esc_html_e('Import Theme Templates', 'taj'); ?>
            </a>
        <?php else : ?>
            <button 
                id="plugin-action" 
                class="button button-primary" 
                data-nonce="<?php echo esc_attr($plugin_nonce); ?>" 
                style="font-size: 1.2em; padding: 10px 20px;"
            >
                <?php esc_html_e('Import Theme Templates', 'taj'); ?>
            </button>
        <?php endif; ?>
        
    </div>
</div>

    <!-- Handle clicks and show loading indicator during AJAX operations -->
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // One Click Demo Import Plugin Install/Activate Button Action
        $('#plugin-action').on('click', function(e) {
            e.preventDefault();
            // Cache the clicked element in a variable for later use
            var $btn = $(this);
            // If the button is an anchor element (<a>), it indicates that the plugin is already installed and activated
            // In this case, redirect the user to the specified URL
            if ($btn.is('a')) {
                window.location.href = $btn.attr('href');
                return;
            }
            $btn.prop('disabled', true).text('<?php esc_html_e("Working.. Please Wait..", "taj"); ?>');
            // Initiate an AJAX POST request
            $.ajax({
                // URL provided by WordPress (admin-ajax.php) to handle AJAX requests
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    // 'action' parameter tells WordPress which PHP function to execute
                    action: 'taj_install_plugin',
                    // Nonce value for security, retrieved from the button's data attribute
                    _ajax_nonce: $btn.data('nonce')
                },
                success: function(response) {
                    if (response.success) {
                    // Upon successful installation/activation, automatically redirect the user to the plugin page
                    window.location.href = "<?php echo admin_url('admin.php?page=one-click-demo-import'); ?>";
                    } else {
                        alert(response.data);
                        // Re-enable the button and restore its original text
                        $btn.prop('disabled', false).text('<?php esc_html_e("Import Theme Templates", "taj"); ?>');
                    }
                },
                error: function() {
                    // In case of a request error, alert the user and restore the button text
                    alert('<?php esc_html_e("An error occurred during the process.. Please try again.", "taj"); ?>');
                    $btn.prop('disabled', false).text('<?php esc_html_e("Import Theme Templates", "taj"); ?>');
                }
            });
        });
        
        // Install/Activate Child Theme Button Action
        $('#child-theme-action').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this);
            // If the button is already disabled, do nothing
            if ($btn.prop('disabled')) {
                return;
            }
            // Disable the button to prevent multiple clicks
            $btn.prop('disabled', true).text('<?php esc_html_e("Working.. Please Wait..", "taj"); ?>');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'taj_install_child_theme',
                    _ajax_nonce: $btn.data('nonce')
                },
                success: function(response) {
                    if (response.success) {
                        $btn.html('&#10004; <?php esc_html_e("Child Theme is Enabled", "taj"); ?>').prop('disabled', true);
                    } else {
                        alert(response.data);
                        $btn.prop('disabled', false).text('<?php esc_html_e("Install and Activate the Child Theme", "taj"); ?>');
                    }
                },
                error: function() {
                    alert('<?php esc_html_e("An error occurred during the process.. Please try again.", "taj"); ?>');
                    $btn.prop('disabled', false).text('<?php esc_html_e("Install and Activate the Child Theme", "taj"); ?>');
                }
            });
        });
    });
    </script>
    <?php
}
