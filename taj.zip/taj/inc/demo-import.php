<?php

/**
 * Define Theme Demos
 *
 * @package Taj
 */

// Load Translation for Import Page
load_theme_textdomain('taj', get_template_directory() . '/languages');

function ocdi_import_files()
{
    // We DO NOT want to import our content via ocdi importer so we should not select the import file url here
    return [
      [
        'import_file_name'           => esc_html__('Educational Academy', 'taj'),
        'import_redux'               => [
            [
              'file_url'    => 'https://taj.wp-arabi.com/files/academy/academy-theme-options.json',
              'option_name' => 'taj_options',
            ],
        ],
        'import_preview_image_url'   => 'https://taj.wp-arabi.com/files/academy/academy-screenshot.jpg',
        'preview_url'                => 'https://taj.wp-arabi.com/academy',
    ]
    ];
}
add_filter('ocdi/import_files', 'ocdi_import_files');

function ocdi_register_plugins($plugins)
{

    // Required: List of plugins used by all theme demos.
    $theme_plugins = [
      [
        'name'     => 'Redux Framework',
        'slug'     => 'redux-framework',
        'required' => true,
      ],
      [
        'name'     => 'Elementor',
        'slug'     => 'elementor',
        'required' => true,
      ],
      [
        'name'     => 'Ultimate Addons for Elementor Lite',
        'slug'     => 'header-footer-elementor',
        'required' => true,
      ],
      [
        'name'     => 'ElementsKit Lite',
        'slug'     => 'elementskit-lite',
        'required' => true,
      ],
      [
        'name'     => 'WPForms',
        'slug'     => 'wpforms-lite',
        'required' => true,
      ],
      [
        'name'     => 'Smart Slider 3',
        'slug'     => 'smart-slider-3',
        'required' => true,
      ],
      [
        'name'     => 'WooCommerce',
        'slug'     => 'woocommerce',
        'required' => true,
      ],
      [
        'name'     => 'Tutor LMS',
        'slug'     => 'tutor',
        'required' => true,
      ],
      [
        'name'     => 'Tutor LMS Elementor Addons',
        'slug'     => 'tutor-lms-elementor-addons',
        'required' => true,
      ]
    ];

    // Check if user is on the theme recommended plugins step and a demo was selected.
    if (
        isset($_GET['step']) && $_GET['step'] === 'import' && isset($_GET['import'])
    ) {

        // Select the plugins that were used in the academy demo only
        if ($_GET['import'] === '0') {
            $theme_plugins = [
              [
                'name'     => 'Redux Framework',
                'slug'     => 'redux-framework',
                'required' => true,
              ],
              [
                'name'     => 'Elementor',
                'slug'     => 'elementor',
                'required' => true,
              ],
              [
                'name'     => 'Ultimate Addons for Elementor Lite',
                'slug'     => 'header-footer-elementor',
                'required' => true,
              ],
              [
                'name'     => 'ElementsKit Lite',
                'slug'     => 'elementskit-lite',
                'required' => true,
              ],
              [
                'name'     => 'WPForms',
                'slug'     => 'wpforms-lite',
                'required' => true,
              ],
              [
                'name'     => 'Smart Slider 3',
                'slug'     => 'smart-slider-3',
                'required' => true,
              ],
              [
                'name'     => 'WooCommerce',
                'slug'     => 'woocommerce',
                'required' => true,
              ],
              [
                'name'     => 'Tutor LMS',
                'slug'     => 'tutor',
                'required' => true,
              ],
              [
                'name'     => 'Tutor LMS Elementor Addons',
                'slug'     => 'tutor-lms-elementor-addons',
                'required' => true,
              ]
            ];
        }

    }

    return array_merge($plugins, $theme_plugins);
}
add_filter('ocdi/register_plugins', 'ocdi_register_plugins');

/*
  * After Import Custom Code Execution
  */

function ocdi_after_import_setup($selected_import)
{
    // Specify the required import name based on the wp control panel language because the esc_html__ function did not work perfectly during the initial run
    if (get_locale() == 'ar') {
        $educational_academy_import_name = 'نموذج موقع أكاديمية تعليمية';
    } else {
        $educational_academy_import_name = 'Educational Academy';
    }

    // Import content based on the selected demo
    if ($educational_academy_import_name  === $selected_import['import_file_name']) {
        $content_url = 'https://taj.wp-arabi.com/files/academy/academy-demo-content.xml';
        $form_urls  = array(
          "https://taj.wp-arabi.com/files/academy/academy-wpforms.json");
        $slider_urls  = array(
          "https://taj.wp-arabi.com/files/academy/academy-slider.ss3");
        $elementor_url = 'https://taj.wp-arabi.com/files/academy/academy-elementor-kit.zip';
        $tutor_url = 'https://taj.wp-arabi.com/files/academy/academy-tutor-options.json';
        $tutor_tables_urls = array("https://taj.wp-arabi.com/files/academy/academy-tutor-quiz-questions.sql","https://taj.wp-arabi.com/files/academy/academy-tutor-quiz-question-answers.sql");
    }

    // We should use wordpress default importer instead of ocdi importer to import our content so we can correctly import tutor lms courses, topics, lessons, quizzes
    if (! defined('WP_LOAD_IMPORTERS')) {
        define('WP_LOAD_IMPORTERS', true);
    }
    // Include the wordpress default importer files
    // Points to the child theme first
    $base  = get_stylesheet_directory() . '/lib/wordpress-importer/';
    if (! file_exists($base)) {
        // Move to the parent theme
        $base = get_template_directory() . '/lib/wordpress-importer/';
    }
    require_once $base . 'wordpress-importer.php';
    require_once $base . 'class-wp-import.php';
    require_once $base . 'compat.php';
    require_once $base . 'parsers.php';
    foreach (glob($base . 'parsers/*.php') as $parser) {
        require_once $parser;
    }
    // Download the file to a temporary path
    $tmp_file = download_url($content_url);
    // Create the object and run the import
    $importer = new WP_Import();
    $importer->fetch_attachments = true;
    $importer->import($tmp_file);
    // Delete the temporary file
    @unlink($tmp_file);

    // Importing forms to WPForms plugin
    foreach ($form_urls as $form_url) {
        $response = wp_remote_get($form_url);
        if (is_wp_error($response)) {
            continue; // If an error occurs while fetching data, ignore the file
        }
        $body = wp_remote_retrieve_body($response);
        $imported_forms = json_decode($body, true);
        // If the file contains more than one form
        foreach ($imported_forms as $form) {
            // Create the form in the database
            $form_id = ! empty($form['id']) ? $form['id'] : 0;
            $form_title  = ! empty($form['settings']['form_title']) ? $form['settings']['form_title'] : '';
            $form_desc   = ! empty($form['settings']['form_desc']) ? $form['settings']['form_desc'] : '';
            $form_data = array(
              'post_title'   => wp_slash($form_title),
              'post_status'  => 'publish',
              'post_type'    => 'wpforms',
              'post_excerpt' => wp_slash($form_desc),
              'post_content' => wpforms_encode($form), // We store the json as wpforms way
              'import_id' => $form_id, // Suggest that the same ID be assigned to the imported form.. this way the short code will be the same
            );
            $form_id = wp_insert_post($form_data);
        }
    }

    // Importing sliders to Smart Slider 3 plugin
    foreach ($slider_urls as $slider_url) {
        // Download file to temporary path
        $temp_file = download_url($slider_url);
        if (! is_wp_error($temp_file)) {
            // Import slider using SmartSlider3 API
            \Nextend\SmartSlider3\PublicApi\Project::import($temp_file);
            // Delete temporary file after import
            @unlink($temp_file);
        }
    }

    // remove welcome message from Smart Slider 3 plugin
    global $wpdb;
    // Add a record to the nextend2_section_storage table to stop the welcome message from appearing
    $wpdb->insert(
        $wpdb->prefix . 'nextend2_section_storage',
        array(
            'application' => 'smartslider',
            'section' => 'tutorial',
            'referencekey' => 'GettingStarted',
            'value' => 1,
            'isSystem' => 0,
            'editable' => 1
        )
    );

    // Importing elementor settings such as colors and fonts
    // Download file to temporary path
    $temp_file = download_url($elementor_url);
    if (! is_wp_error($temp_file)) {
        // Get elementor import export component to use import_kit function
        $import_export_module = \Elementor\Plugin::$instance->app->get_component('import-export');
        $settings = array();
        $import_export_module->import_kit($temp_file, $settings, false);
        // Delete temporary file after import
        @unlink($temp_file);
    }

    // Importing tutor lms settings
    // Fetch content
    $response = wp_remote_get($tutor_url);
    $body = wp_remote_retrieve_body($response);
    $json = json_decode($body, true);
    $dataset = $json['data'];
    $time    = time();
    // Setting the registry data as in the tutor_import_settings function
    $save_import_data = array(
        'datetime'     => (int) $time,
        'history_date' => gmdate('j M, Y, g:i a', $time),
        'datatype'     => 'imported',
        'dataset'      => $dataset,
    );
    $import_key        = 'tutor-imported-' . $time;
    $import_data       = array( $import_key => $save_import_data );
    $existing_log      = get_option('tutor_settings_log', array());
    // Merge the old record with the new one
    $updated_log = array_merge($import_data, $existing_log);
    update_option('tutor_settings_log', tutor_utils()->sanitize_recursively($updated_log));
    // Save the Tutor LMS settings
    update_option('tutor_option', $dataset);
    // Edit elementor post types to support single course page template
    update_option('elementor_cpt_support', [ 'post', 'page', 'courses' ]);

    // Importing tutor lms questions and answers tables
    $old_prefix = 'wp_2_';
    $new_prefix = $wpdb->prefix;
    foreach ($tutor_tables_urls as $tutor_table_url) {
        // Fetch file
        $response = wp_remote_get($tutor_table_url);
        // Content processing
        $sql = wp_remote_retrieve_body($response);
        // Prefix replacement
        $sql = str_replace($old_prefix, $new_prefix, $sql);
        // Split and execute queries
        $queries = preg_split('/;\s*[\r\n]+/', trim($sql));
        foreach ($queries as $query) {
            $query = trim($query);
            if (! empty($query)) {
                $wpdb->query($query);
            }
        }
    }

    // Assign front page and posts page (blog page)
    $front_page_id = get_page_by_title('الصفحة الرئيسية');
    $blog_page_id  = get_page_by_title('المدونة');
    update_option('show_on_front', 'page');
    update_option('page_on_front', $front_page_id->ID);
    update_option('page_for_posts', $blog_page_id->ID);

    // Set permalink structure to post-name
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');
    $wp_rewrite->flush_rules(true);
}
add_action('ocdi/after_import', 'ocdi_after_import_setup');

// Translate the import result text that comes from AJAX into arabic
function taj_ocdi_gettext_override($translated_text, $text, $domain)
{
    if ('one-click-demo-import' !== $domain) {
        return $translated_text;
    }

    if (get_locale() == 'ar' && $domain === 'one-click-demo-import' && $text === 'Import Complete!') {
        $translated_text = 'اكتمل الاستيراد بنجاح!';
    }

    if (get_locale() == 'ar' && $domain === 'one-click-demo-import' && $text === 'Congrats, your demo was imported successfully. You can now begin editing your site.') {
        $translated_text = 'تهانينا، تم استيراد بيانات النموذج بنجاح. يمكنك الآن البدء في تعديل موقعك.';
    }

    return $translated_text;
}

add_filter('gettext', 'taj_ocdi_gettext_override', 20, 3);
