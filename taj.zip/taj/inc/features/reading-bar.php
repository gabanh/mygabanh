<?php

/**
 * Register and apply reading bar feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_footer', 'taj_reading_bar_feature');

function taj_reading_bar_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_reading_bar_posts_status = $taj_options['taj_reading_bar_posts_status'];
    $taj_reading_bar_pages_status = $taj_options['taj_reading_bar_pages_status'];
    $taj_reading_bar_position = $taj_options['taj_reading_bar_position'];
    $taj_reading_bar_height = $taj_options['taj_reading_bar_height'];
    $taj_reading_bar_color = $taj_options['taj_reading_bar_color'];

    // set the values for reading bar position
    if ($taj_reading_bar_position == 1) {
        // show the reading bar under the wp admin bar
        if (is_user_logged_in()) {
            $taj_whatsapp_button_position_top="32px";
        } else {
            $taj_whatsapp_button_position_top="0px";
        }
        $taj_whatsapp_button_position_bottom="auto";
    } elseif ($taj_reading_bar_position == 2) {
        $taj_whatsapp_button_position_top="auto";
        $taj_whatsapp_button_position_bottom="0px";
    }

    // show reading bar for posts
    if ($taj_reading_bar_posts_status == 1 && is_singular('post') ) {
        ?>
<div id="tajReadingBar"></div>
        <?php
    }

    // show reading bar for pages
    if ($taj_reading_bar_pages_status == 1 && (is_page() || is_home())) {
        ?>
<div id="tajReadingBar"></div>
        <?php
    }

    // print the css style for reading bar only if the user want to use it
    if ($taj_reading_bar_posts_status == 1 || $taj_reading_bar_pages_status == 1) {
        ?>
<style>

#tajReadingBar {
	--scrollAmount: 0%;
	background-color: <?php echo $taj_reading_bar_color; ?>;
	width: var(--scrollAmount);
	height: <?php echo $taj_reading_bar_height; ?>px;
	position: fixed;
	top: <?php echo $taj_whatsapp_button_position_top; ?>;
    bottom: <?php echo $taj_whatsapp_button_position_bottom; ?>;
	z-index: 999999;
}

</style>
<?php
    }
}
