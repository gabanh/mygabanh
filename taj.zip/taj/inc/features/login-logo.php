<?php

/**
 * Register and apply login logo feature only if the user enable it
 *
 * @package    taj
 */


add_action('login_head', 'taj_login_logo_feature');

function taj_login_logo_feature()
{
    // Global Options
    global $taj_options;

    if ($taj_options['taj_login_logo_switch']) {

        // Get the user options from taj Control Panel
        $taj_login_logo_image = $taj_options['taj_login_logo_image']['url'];
        $taj_login_logo_width = $taj_options['taj_login_logo_width'];
        $taj_login_logo_height = $taj_options['taj_login_logo_height'];
        ?>
<style>

.login h1 a {
  background-image:url(<?php echo $taj_login_logo_image; ?>) !important;
  width: <?php echo $taj_login_logo_width; ?>px !important;
  height: <?php echo $taj_login_logo_height; ?>px !important;
  background-size:cover !important;
}

</style>
<?php
    }
}

/* Change the URL of the login logo and make it a link to the same site */

add_filter('login_headerurl', 'taj_change_login_logo_url');

function taj_change_login_logo_url($url)
{
    // Global Options
    global $taj_options;

    if ($taj_options['taj_login_logo_switch']) {
        return home_url();
    }
    return $url;
}
