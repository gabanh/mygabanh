<?php

/**
 * Register and apply banner feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_footer', 'taj_banner_feature');

function taj_banner_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    // IMPORTANT: the position of the banner is set by JavaScript

    $taj_banner_text = $taj_options['taj_banner_text'];
    $taj_banner_close_button_expiration = $taj_options['taj_banner_close_button_expiration'];
    $taj_banner_show_mobile = $taj_options['taj_banner_show_mobile'];
    $taj_banner_show_shadow = $taj_options['taj_banner_show_shadow'];
    $taj_banner_show_close_button = $taj_options['taj_banner_show_close_button'];
    $taj_banner_text_font_size = $taj_options['taj_banner_text_font_size'];
    $taj_banner_close_button_size = $taj_options['taj_banner_close_button_size'];
    $taj_banner_close_button_shape = $taj_options['taj_banner_close_button_shape'];
    $taj_banner_text_color = $taj_options['taj_banner_text_color'];
    $taj_banner_link_color = $taj_options['taj_banner_link_color'];
    $taj_banner_bg_color = $taj_options['taj_banner_bg_color'];
    $taj_banner_close_button_color = $taj_options['taj_banner_close_button_color'];
    
    // set the values for button show on mobile
    if ($taj_banner_show_mobile == 1) {
        $taj_banner_show_mobile="block";
    } elseif ($taj_banner_show_mobile == 2) {
        $taj_banner_show_mobile="none";
    }

     // set the values for button show shadow
    if ($taj_banner_show_shadow == 1) {
        $taj_banner_show_shadow="0 1px 1em rgb(0 0 0 / 20%);";
    } elseif ($taj_banner_show_shadow == 2) {
        $taj_banner_show_shadow="none";
    }

    // set the values for show close button
    if ($taj_banner_show_close_button == 1) {
        $taj_banner_show_close_button="block";
    } elseif ($taj_banner_show_close_button == 2) {
        $taj_banner_show_close_button="none";
    }

    // output the banner if the banner text not empty
    if($taj_banner_text != '')
    {
    ?>
<div class="tajBanner" id="tajBanner">
    <p><?php echo $taj_banner_text; ?></p>
    <button class="tajBannerCloseButton" onClick="tajBannerClose()"><i
            class="fa-solid fa-<?php echo $taj_banner_close_button_shape; ?>"></i></button>
</div>

<style>
.tajBanner {
    right: 0px;
    left: 0px;
    width: 100%;
    height:auto;
    background-color: <?php echo $taj_banner_bg_color;
    ?>;
    padding: 1em 0;
    transition: 0.5s;
    -moz-transition: 0.5s;
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    box-shadow: <?php echo $taj_banner_show_shadow;
    ?>;
    z-index: 99999;
}

.tajBanner p {
    color: <?php echo $taj_banner_text_color;
    ?>;
    font-size: <?php echo $taj_banner_text_font_size;
    ?>px;
    text-align: center;
    margin: 5px 0px 0px 0px;
    line-height: normal;
}

.tajBanner a {
    color: <?php echo $taj_banner_link_color;
    ?>;
}

.tajBannerCloseButton {
    font-size: 10px;
    line-height: 0px;
    border: none;
    position: absolute;
    top: 50%;
    transform: translate(10px, -50%);
    right: auto;
    left: 0;
    background: none;
    display:<?php echo $taj_banner_show_close_button;
    ?>;
}

.tajBannerCloseButton i {
    color: <?php echo $taj_banner_close_button_color;
    ?>;
    font-size: <?php echo $taj_banner_close_button_size;
    ?>px;
}

@media only screen and (max-width: 768px) {

    /* For mobile phones: */
    .tajBanner {
        display: <?php echo $taj_banner_show_mobile;
        ?>;
    }
}
</style>
<?php
}}