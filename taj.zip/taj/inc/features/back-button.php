<?php

/**
 * Register and apply back to top button feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_footer', 'taj_back_button_feature');

function taj_back_button_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_back_button_position = $taj_options['taj_back_button_position'];
    $taj_back_button_shape = $taj_options['taj_back_button_shape'];
    $taj_back_button_show_mobile = $taj_options['taj_back_button_show_mobile'];
    $taj_back_button_show_shadow = $taj_options['taj_back_button_show_shadow'];
    $taj_back_button_size = $taj_options['taj_back_button_size'];
    $taj_back_button_icon_size = $taj_options['taj_back_button_icon_size'];
    $taj_back_button_icon_type = $taj_options['taj_back_button_icon_type'];
    $taj_back_button_icon_color = $taj_options['taj_back_button_icon_color'];
    $taj_back_button_icon_color_hover = $taj_options['taj_back_button_icon_color_hover'];
    $taj_back_button_icon_bg_color = $taj_options['taj_back_button_icon_bg_color'];
    $taj_back_button_icon_bg_color_hover = $taj_options['taj_back_button_icon_bg_color_hover'];

    // set the values for button position
    // Right means 1 & Left means 2
    if ($taj_back_button_position == 1) {
        $taj_back_button_position_right="20px";
        $taj_back_button_position_left="auto";
    } elseif ($taj_back_button_position == 2) {
        $taj_back_button_position_right="auto";
        $taj_back_button_position_left="20px";
    }

    // set the values for button type (border radius)
    // Circle means 1 & Square means 2
    if ($taj_back_button_shape == 1) {
        $taj_back_button_shape=50;
    } elseif ($taj_back_button_shape == 2) {
        $taj_back_button_shape=0;
    }

    // set the values for button show on mobile
    // Show means 1 & Hide means 2
    if ($taj_back_button_show_mobile == 1) {
        $taj_back_button_show_mobile="block";
    } elseif ($taj_back_button_show_mobile == 2) {
        $taj_back_button_show_mobile="none";
    }

    // set the values for button show shadow
    // Show means 1 & Hide means 2
    if ($taj_back_button_show_shadow == 1) {
        $taj_back_button_show_shadow="1px 6px 24px 0 rgb(7 94 84 / 24%)";
    } elseif ($taj_back_button_show_shadow == 2) {
        $taj_back_button_show_shadow="none";
    }

    ?>
        <button class="tajScrollToTopBtn"><i class="fa fa-<?php echo $taj_back_button_icon_type; ?>"></i></button>
        <style>
        .tajScrollToTopBtn {
            position: fixed;
            bottom: 20px;
            right: <?php echo $taj_back_button_position_right;
    ?>;
            left: <?php echo $taj_back_button_position_left;
    ?>;
            width: <?php echo $taj_back_button_size;
    ?>px;
            height: <?php echo $taj_back_button_size;
    ?>px;
            border-radius: <?php echo $taj_back_button_shape;
    ?>%;
            display: block;
            background-color: <?php echo $taj_back_button_icon_bg_color;
    ?>;
            padding: 8px 4px;
            cursor: pointer;
            border: none;
            line-height: 0px;
            transform: translateY(100px);
            opacity: 0;
            transition: 0.5s;
            -moz-transition: 0.5s;
            -webkit-transition: 0.5s;
            -o-transition: 0.5s;
            box-shadow: <?php echo $taj_back_button_show_shadow;
    ?>;
    z-index: 99999;
        }

        .tajScrollToTopBtn:hover {
            background-color: <?php echo $taj_back_button_icon_bg_color_hover;
    ?>;
        }

        .tajScrollToTopBtn i {
            color: <?php echo $taj_back_button_icon_color;
    ?>;
            font-size: <?php echo $taj_back_button_icon_size;
    ?>px;
    transition: 0.2s;
            -moz-transition: 0.2s;
            -webkit-transition: 0.2s;
            -o-transition: 0.2s;
        }

        .tajScrollToTopBtn:hover i {
            color: <?php echo $taj_back_button_icon_color_hover;
    ?>;
        }

        .showScrollBtn {
            transform: translateY(0);
            opacity: 1;
        }

        @media only screen and (max-width: 768px) {

            /* For mobile phones: */
            .showScrollBtn {
                display: <?php echo $taj_back_button_show_mobile;
    ?>;
            }
        }
        </style>
        <?php
}
