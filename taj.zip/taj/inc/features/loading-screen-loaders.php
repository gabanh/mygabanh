<?php

/**
 * include only the style of the loader that has selected by the user
 *
 * @package    taj
 */

switch($taj_loading_screen_icon_type) {
    case'1':
        ?>
<style>
.loader-1 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 5px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-bottom-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    animation: rotation 1s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'2':
        ?>
<style>
.loader-2 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;

}

.loader-2:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: <?php echo $taj_loading_screen_icon_size-8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size-8;
    ?>px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-bottom-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'3':
        ?>
<style>
.loader-3 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-3:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: <?php echo $taj_loading_screen_icon_size+8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size+8;
    ?>px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-bottom-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'4':
        ?>
<style>
.loader-4 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-4:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: <?php echo $taj_loading_screen_icon_size-8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size-8;
    ?>px;
    border-radius: 50%;
    border: 3px solid;
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?> transparent;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'5':
        ?>
<style>
.loader-5 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-5:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: <?php echo $taj_loading_screen_icon_size+8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size+8;
    ?>px;
    border-radius: 50%;
    border: 3px solid;
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?> transparent;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'6':
        ?>
<style>
.loader-6 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-6:after,
.loader-6:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/8;
    ?>px;
    transform: translate(150%, 150%);
    border-radius: 50%;
}

.loader-6:before {
    left: auto;
    top: auto;
    right: 0;
    bottom: 0;
    transform: translate(-150%, -150%);
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'7':
        ?>
<style>
.loader-7 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-7:after,
.loader-7:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/8;
    ?>px;
    border-radius: 50%;
}

.loader-7:before {
    left: auto;
    top: auto;
    right: 0;
    bottom: 0;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'8':
        ?>
<style>
.loader-8 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-8:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    transform: translate(-50%, 50%);
    border-radius: 50%;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'9':
        ?>
<style>
.loader-9 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    border: 2px solid <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    animation: rotation 1s linear infinite;
}

.loader-9:after {
    content: '';
    position: absolute;
    left: 4px;
    top: 4px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/4;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/4;
    ?>px;
    border-radius: 50%;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'10':
        ?>
<style>
.loader-10 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    border: 3px solid;
    border-color: <?php echo $taj_loading_screen_icon_primary_color;
    ?><?php echo $taj_loading_screen_icon_primary_color;
    ?> transparent;
    animation: rotation 1s linear infinite;
}

.loader-10:after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    border: 3px solid;
    border-color: transparent <?php echo $taj_loading_screen_icon_secondary_color;
    ?><?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    border-radius: 50%;
    animation: rotationBack 0.5s linear infinite;
    transform-origin: center center;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}

@keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}
</style>
<?php
    break;
    case'11':
        ?>
<style>
.loader-11 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    border: 3px solid;
    border-color: <?php echo $taj_loading_screen_icon_primary_color;
    ?><?php echo $taj_loading_screen_icon_primary_color;
    ?> transparent transparent;
    animation: rotation 1s linear infinite;
}

.loader-11:after,
.loader-11:before {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    border: 3px solid;
    border-color: transparent transparent <?php echo $taj_loading_screen_icon_secondary_color;
    ?> <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size-8;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size-8; ?>px;
    border-radius: 50%;
    animation: rotationBack 0.5s linear infinite;
    transform-origin: center center;
}

.loader-11:before {
    width: <?php echo $taj_loading_screen_icon_size-16; ?>px;
    height: <?php echo $taj_loading_screen_icon_size-16; ?>px;
    border-color: <?php echo $taj_loading_screen_icon_primary_color;
    ?> <?php echo $taj_loading_screen_icon_primary_color;
    ?> transparent transparent;
    animation: rotation 1.5s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}

@keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}
</style>
<?php
    break;
    case'12':
        ?>
<style>
.loader-12 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 3px dotted <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-style: solid solid dotted dotted;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 2s linear infinite;
}

.loader-12:after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    border: 3px dotted <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-style: solid solid dotted;
    width: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    border-radius: 50%;
    animation: rotationBack 1s linear infinite;
    transform-origin: center center;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}

@keyframes rotationBack {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(-360deg);
    }
}
</style>
<?php
    break;
    case'13':
        ?>
<style>
.loader-13 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-13:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: 3px;
    height: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    transform: translateX(-50%);
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'14':
        ?>
<style>
.loader-14 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-14::after,
.loader-14::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: animloader14 2s linear infinite;
}

.loader-14::after {
    animation-delay: 1s;
}

@-webkit-keyframes animloader14 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}

@keyframes animloader14 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}
</style>
<?php
    break;
    case'15':
        ?>
<style>
.loader-15 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 5px dotted <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 2s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'16':
        ?>
<style>
.loader-16 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    border-top: 3px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-right: 3px solid transparent;
    animation: rotation 1s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'17':
        ?>
<style>
.loader-17 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    border-top: 4px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-right: 4px solid transparent;
    animation: rotation 1s linear infinite;
}

.loader-17:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    border-bottom: 4px solid <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-left: 4px solid transparent;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'18':
        ?>
<style>
.loader-18 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    border-top: 4px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-right: 4px solid transparent;
    animation: rotation 1s linear infinite;
}

.loader-18:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    border-left: 4px solid <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-bottom: 4px solid transparent;
    animation: rotation 0.5s linear infinite reverse;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'19':
        ?>
<style>
.loader-19 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 5px solid;
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?> transparent;
    border-radius: 50%;
    display: inline-block;
    animation: rotation 1s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'20':
        ?>
<style>
.loader-20 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    border: 10px solid;
    animation: animloader20 1s linear infinite alternate;
}

@-webkit-keyframes animloader20 {
    0% {
        border-color: white rgba(255, 255, 255, 0) rgba(255, 255, 255, 0) rgba(255, 255, 255, 0);
    }

    33% {
        border-color: white white rgba(255, 255, 255, 0) rgba(255, 255, 255, 0);
    }

    66% {
        border-color: white white white rgba(255, 255, 255, 0);
    }

    100% {
        border-color: white white white white;
    }
}

@keyframes animloader20 {
    0% {
        border-color: white rgba(255, 255, 255, 0) rgba(255, 255, 255, 0) rgba(255, 255, 255, 0);
    }

    33% {
        border-color: white white rgba(255, 255, 255, 0) rgba(255, 255, 255, 0);
    }

    66% {
        border-color: white white white rgba(255, 255, 255, 0);
    }

    100% {
        border-color: white white white white;
    }
}
</style>
<?php
    break;
    case'21':
        ?>
<style>
.loader-21 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    display: inline-block;
    border-radius: 50%;
    animation: animloader21 1s ease-in infinite;
}
@-webkit-keyframes animloader21 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}

@keyframes animloader21 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}
</style>
<?php
    break;
    case'22':
        ?>
<style>
.loader-22 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-22::after,
.loader-22::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: animloader22 2s linear infinite;
}

.loader-22::after {
    animation-delay: 1s;
}
@-webkit-keyframes animloader22 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}

@keyframes animloader22 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}
</style>
<?php
    break;
    case'23':
        ?>
<style>
.loader-23 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-23::after,
.loader-23::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: animloader23 2s ease-in-out infinite;
}

.loader-23::after {
    animation-delay: 1s;
}

@-webkit-keyframes animloader23 {

    0%,
    100% {
        transform: scale(0);
        opacity: 1;
    }

    50% {
        transform: scale(1);
        opacity: 0;
    }
}

@keyframes animloader23 {

    0%,
    100% {
        transform: scale(0);
        opacity: 1;
    }

    50% {
        transform: scale(1);
        opacity: 0;
    }
}
</style>
<?php
    break;
    case'24':
        ?>
<style>
.loader-24 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    animation: animloader24 1s linear infinite;
}

@-webkit-keyframes animloader24 {
    0% {
        box-shadow: -72px 0 #fff inset;
    }

    100% {
        box-shadow: 48px 0 #fff inset;
    }
}

@keyframes animloader24 {
    0% {
        box-shadow: -72px 0 #fff inset;
    }

    100% {
        box-shadow: 48px 0 #fff inset;
    }
}
</style>
<?php
    break;
    case'25':
        ?>
<style>
.loader-25 {
    border: <?php echo $taj_loading_screen_icon_size/2;
    ?>px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-bottom-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'26':
        ?>
<style>
.loader-26 {
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 2s linear infinite;
}

.loader-26:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    border: <?php echo $taj_loading_screen_icon_size/2;
    ?>px solid;
    border-color: transparent <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    transform: translate(-50%, -50%);
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'27':
        ?>
<style>
.loader-27 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 4px solid;
    background: rgba(<?php echo $taj_loading_screen_icon_primary_color; ?>, 0.2);
    border-color: transparent <?php echo $taj_loading_screen_icon_primary_color;
    ?><?php echo $taj_loading_screen_icon_primary_color;
    ?> transparent;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s ease-in-out infinite;
}

.loader-27:after {
    content: '';
    position: absolute;
    left: 50%;
    top: 50%;
    border: <?php echo $taj_loading_screen_icon_size/4;
    ?>px solid;
    border-color: transparent <?php echo $taj_loading_screen_icon_secondary_color;
    ?><?php echo $taj_loading_screen_icon_secondary_color;
    ?> transparent;
    transform: translate(-50%, -50%);
    border-radius: 50%;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'28':
        ?>
<style>
.loader-28 {
    border: <?php echo $taj_loading_screen_icon_size/2;
    ?>px solid;
    border-color: rgba(<?php echo $taj_loading_screen_icon_primary_color; ?>, 0.15) rgba(<?php echo $taj_loading_screen_icon_primary_color; ?>, 0.25) rgba(<?php echo $taj_loading_screen_icon_primary_color; ?>, 0.35) rgba(<?php echo $taj_loading_screen_icon_primary_color; ?>, 0.5);
    border-radius: 50%;
    display: inline-block;
    animation: animloader28 1s linear infinite;
}

@-webkit-keyframes animloader28 {
    0% {
        border-color: rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75);
    }

    33% {
        border-color: rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35);
    }

    66% {
        border-color: rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25);
    }

    100% {
        border-color: rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15);
    }
}

@keyframes animloader28 {
    0% {
        border-color: rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75);
    }

    33% {
        border-color: rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35);
    }

    66% {
        border-color: rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15) rgba(255, 255, 255, 0.25);
    }

    100% {
        border-color: rgba(255, 255, 255, 0.25) rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.75) rgba(255, 255, 255, 0.15);
    }
}
</style>
<?php
    break;
    case'29':
        ?>
<style>
.loader-29 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: rotation 1s linear infinite;
}

.loader-29:after,
.loader-29:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    transform: translate(-50%, 50%);
    border-radius: 50%;
}

.loader-29:before {
    left: auto;
    right: 0;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    transform: translate(50%, 100%);
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'30':
        ?>
<style>
.loader-30 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    animation: zeroRotation 1s linear infinite alternate;
}

.loader-30:after,
.loader-30:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    transform: translate(-50%, 50%);
    border-radius: 50%;
}

.loader-30:before {
    left: auto;
    right: 0;
    transform: translate(50%, 100%);
}

@-webkit-keyframes zeroRotation {
    0% {
        transform: scale(1) rotate(0deg);
    }

    100% {
        transform: scale(0) rotate(360deg);
    }
}

@keyframes zeroRotation {
    0% {
        transform: scale(1) rotate(0deg);
    }

    100% {
        transform: scale(0) rotate(360deg);
    }
}
</style>
<?php
    break;
    case'31':
        ?>
<style>
.loader-31 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
    color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    animation: rotation 1s linear infinite;
}

.loader-31:after,
.loader-31:before {
    content: '';
    position: absolute;
    width: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    top: 0;
    background-color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    animation: scale31 1s infinite ease-in-out;
}

.loader-31:before {
    top: auto;
    bottom: 0;
    background-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    animation-delay: 0.5s;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes scale31 {

    0%,
    100% {
        transform: scale(0);
    }

    50% {
        transform: scale(1);
    }
}

@keyframes scale31 {

    0%,
    100% {
        transform: scale(0);
    }

    50% {
        transform: scale(1);
    }
}
</style>
<?php
    break;
    case'32':
        ?>
<style>
.loader-32 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
    color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    animation: rotation 1s linear infinite;
}

.loader-32:after,
.loader-32:before {
    content: '';
    position: absolute;
    width: <?php echo $taj_loading_screen_icon_size/2; ?>px;
    height: <?php echo $taj_loading_screen_icon_size/2;
    ?>px;
    top: 50%;
    left: 50%;
    transform: scale(0.5) translate(0, 0);
    background-color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    border-radius: 50%;
    animation: animloader32 1s infinite ease-in-out;
}

.loader-32:before {
    background-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    transform: scale(0.5) translate(-<?php echo $taj_loading_screen_icon_size; ?>px, -<?php echo $taj_loading_screen_icon_size; ?>px);
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@-webkit-keyframes animloader32 {
    50% {
        transform: scale(1) translate(-50%, -50%);
    }
}

@keyframes animloader32 {
    50% {
        transform: scale(1) translate(-50%, -50%);
    }
}
</style>
<?php
    break;
    case'33':
        ?>
<style>
.loader-33 {
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    animation: shadowExpandX 2s linear infinite alternate;
}

@-webkit-keyframes shadowExpandX {
    0% {
        box-shadow: 0 0, 0 0;
        color: rgba(255, 255, 255, 0.2);
    }

    100% {
        box-shadow: -24px 0, 24px 0;
        color: rgba(255, 255, 255, 0.8);
    }
}

@keyframes shadowExpandX {
    0% {
        box-shadow: 0 0, 0 0;
        color: rgba(255, 255, 255, 0.2);
    }

    100% {
        box-shadow: -24px 0, 24px 0;
        color: rgba(255, 255, 255, 0.8);
    }
}
</style>
<?php
    break;
    case'34':
        ?>
<style>
.loader-34 {
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    background: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    box-shadow: -<?php echo $taj_loading_screen_icon_size/2;
    ?>px 0 <?php echo $taj_loading_screen_icon_primary_color;
    ?>,
    <?php echo $taj_loading_screen_icon_size/2;
    ?>px 0 <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    animation: shadowPulse 2s linear infinite;
}

@-webkit-keyframes shadowPulse {
    33% {
        background: #fff;
        box-shadow: -24px 0 #2271b1, 24px 0 #fff;
    }

    66% {
        background: #2271b1;
        box-shadow: -24px 0 #fff, 24px 0 #fff;
    }

    100% {
        background: #fff;
        box-shadow: -24px 0 #fff, 24px 0 #2271b1;
    }
}

@keyframes shadowPulse {
    33% {
        background: #fff;
        box-shadow: -24px 0 #2271b1, 24px 0 #fff;
    }

    66% {
        background: #2271b1;
        box-shadow: -24px 0 #fff, 24px 0 #fff;
    }

    100% {
        background: #fff;
        box-shadow: -24px 0 #fff, 24px 0 #2271b1;
    }
}
</style>
<?php
    break;
    case'35':
        ?>
<style>
.loader-35 {
    width: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size/3;
    ?>px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    background: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    box-shadow: -<?php echo $taj_loading_screen_icon_size/2;
    ?>px 0,
    <?php echo $taj_loading_screen_icon_size/2;
    ?>px 0;
    animation: rotation 2s ease-in-out infinite;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'36':
        ?>
<style>
.loader-36 {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    color: <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    left: -100px;
    animation: shadowRolling 2s linear infinite;
}

@-webkit-keyframes shadowRolling {
    0% {
        box-shadow: 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    12% {
        box-shadow: 100px 0 white, 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    25% {
        box-shadow: 110px 0 white, 100px 0 white, 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    36% {
        box-shadow: 120px 0 white, 110px 0 white, 100px 0 white, 0px 0 rgba(255, 255, 255, 0);
    }

    50% {
        box-shadow: 130px 0 white, 120px 0 white, 110px 0 white, 100px 0 white;
    }

    62% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 130px 0 white, 120px 0 white, 110px 0 white;
    }

    75% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 130px 0 white, 120px 0 white;
    }

    87% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 130px 0 white;
    }

    100% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0);
    }
}

@keyframes shadowRolling {
    0% {
        box-shadow: 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    12% {
        box-shadow: 100px 0 white, 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    25% {
        box-shadow: 110px 0 white, 100px 0 white, 0px 0 rgba(255, 255, 255, 0), 0px 0 rgba(255, 255, 255, 0);
    }

    36% {
        box-shadow: 120px 0 white, 110px 0 white, 100px 0 white, 0px 0 rgba(255, 255, 255, 0);
    }

    50% {
        box-shadow: 130px 0 white, 120px 0 white, 110px 0 white, 100px 0 white;
    }

    62% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 130px 0 white, 120px 0 white, 110px 0 white;
    }

    75% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 130px 0 white, 120px 0 white;
    }

    87% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 130px 0 white;
    }

    100% {
        box-shadow: 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0), 200px 0 rgba(255, 255, 255, 0);
    }
}
</style>
<?php
    break;
    case'37':
        ?>
<style>
.loader-37 {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: inline-block;
    position: relative;
}

.loader-37::after {
    content: '';
    width: 16px;
    height: 16px;
    border-radius: 50%;
    position: absolute;
    left: 0;
    transform: translate(-50%, 100%);
    animation: animloader37 1s linear infinite;
    top: 0;
}

@-webkit-keyframes animloader37 {
    0% {
        background: white;
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    14% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px white, 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    28% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px white, 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    42% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px white, 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    57% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px white, 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    71% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px white, 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    85% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px white;
    }

    100% {
        background: rgba(255, 255, 255, 0.5);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }
}

@keyframes animloader37 {
    0% {
        background: white;
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    14% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px white, 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    28% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px white, 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    42% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px white, 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    57% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px white, 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    71% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px white, 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }

    85% {
        background: rgba(255, 255, 255, 0);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px white;
    }

    100% {
        background: rgba(255, 255, 255, 0.5);
        box-shadow: 9px -19px 0 -1px rgba(255, 255, 255, 0), 28px -19px 0 -2px rgba(255, 255, 255, 0), 39px -5px 0 -3px rgba(255, 255, 255, 0), 34px 10px 0 -4px rgba(255, 255, 255, 0), 22px 17px 0 -5px rgba(255, 255, 255, 0), 9px 16px 0 -6px rgba(255, 255, 255, 0);
    }
}
</style>
<?php
    break;
    case'38':
        ?>
<style>
.loader-38 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-38::after,
.loader-38::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: rotation 2s ease-in-out infinite;
}

.loader-38::after {
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    animation-delay: 1s;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
    case'39':
        ?>
<style>
.loader-39 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-39::after,
.loader-39::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 4px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: animloader39 2s ease-in-out infinite;
}

.loader-39::after {
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    animation-delay: 1s;
}
@-webkit-keyframes animloader39 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}

@keyframes animloader39 {
    0% {
        transform: scale(0);
        opacity: 1;
    }

    100% {
        transform: scale(1);
        opacity: 0;
    }
}
</style>
<?php
    break;
    case'40':
        ?>
<style>
.loader-40 {
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    display: inline-block;
    position: relative;
}

.loader-40::after,
.loader-40::before {
    content: '';
    width: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    height: <?php echo $taj_loading_screen_icon_size;
    ?>px;
    border: 2px solid <?php echo $taj_loading_screen_icon_primary_color;
    ?>;
    position: absolute;
    left: 0;
    top: 0;
    animation: rotation 2s ease-in-out infinite alternate;
}

.loader-40::after {
    border-color: <?php echo $taj_loading_screen_icon_secondary_color;
    ?>;
    animation-direction: alternate-reverse;
}

@-webkit-keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

@keyframes rotation {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}
</style>
<?php
    break;
}