<?php

/**
 * Register and apply mouse cursor feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_footer', 'taj_mouse_cursor_feature');

function taj_mouse_cursor_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_mouse_cursor_color = $taj_options['taj_mouse_cursor_color'];
    $taj_mouse_cursor_outer_color = $taj_options['taj_mouse_cursor_outer_color'];
    $taj_mouse_cursor_color_hover_type2 = $taj_options['taj_mouse_cursor_color_hover_type2'];
    $taj_mouse_cursor_color_hover_type3 = $taj_options['taj_mouse_cursor_color_hover_type3'];
    $taj_mouse_cursor_outer_color_hover_type3 = $taj_options['taj_mouse_cursor_outer_color_hover_type3'];


    ?>
<style>
body #magicMouseCursor{
    border:1px solid <?php echo $taj_mouse_cursor_outer_color; ?>;
    z-index:9999999;
}

body #magicPointer{
    background:<?php echo $taj_mouse_cursor_color; ?>;
    z-index:9999999;
}

body #magicPointer.pointer-blur{
    border:1px solid <?php echo $taj_mouse_cursor_color_hover_type2; ?>;
    box-shadow:0px 0px 15px -5px <?php echo $taj_mouse_cursor_color_hover_type2; ?>;
}

body #magicPointer.is-hover{
    background:<?php echo $taj_mouse_cursor_color_hover_type3; ?>;
}

body #magicMouseCursor.is-hover{
    border:1px solid <?php echo $taj_mouse_cursor_outer_color_hover_type3; ?> !important;
}

</style>
<?php
}