<?php

/**
 * Register and apply loading screen feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_head', 'taj_loading_screen_feature');

function taj_loading_screen_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_loading_screen_icon_type = $taj_options['taj_loading_screen_icon_type'];
    $taj_loading_screen_show_mobile = $taj_options['taj_loading_screen_show_mobile'];
    $taj_loading_screen_icon_size = $taj_options['taj_loading_screen_icon_size'];
    $taj_loading_screen_icon_primary_color = $taj_options['taj_loading_screen_icon_primary_color'];
    $taj_loading_screen_icon_secondary_color = $taj_options['taj_loading_screen_icon_secondary_color'];
    $taj_loading_screen_bg_color = $taj_options['taj_loading_screen_bg_color'];

    // set the values for button show on mobile
    if ($taj_loading_screen_show_mobile == 1) {
        $taj_loading_screen_show_mobile="flex";
    } elseif ($taj_loading_screen_show_mobile == 2) {
        $taj_loading_screen_show_mobile="none";
    }

    ?>
<div class="tajLoadingScreen">
    <span class="loader-<?php echo $taj_loading_screen_icon_type; ?>"> </span>
</div>

<style>

html
{
    overflow:hidden;
}

.tajLoadingScreen {
    width: 100vw;
    height: 100vh;
    position: fixed;
    top: 0px;
    left: 0px;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    background-color: <?php echo $taj_loading_screen_bg_color;
    ?>;
}

@media only screen and (max-width: 768px) {

    /* For mobile phones: */
    .tajLoadingScreen {
        display: <?php echo $taj_loading_screen_show_mobile;
        ?>;
    }
}

.hidetajLoadingScreen {
    opacity: 0;
    transition: opacity 800ms;
}
</style>
<?php

// include only the style of the loader that has selected by the user
require_once locate_template('/inc/features/loading-screen-loaders.php');
}