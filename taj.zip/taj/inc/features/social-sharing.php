<?php
/**
 * Taj Social Sharing Function
 *
 * @package taj
 */
?>

<div class="text-center social-share">
    <h3><?php  echo esc_html__('Share this article', 'taj') ?></h3>
    <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
        <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
        <a class="a2a_button_facebook"></a>
        <a class="a2a_button_x"></a>
        <a class="a2a_button_email"></a>
        <a class="a2a_button_whatsapp"></a>
        <a class="a2a_button_telegram"></a>
        <a class="a2a_button_facebook_messenger"></a>
    </div>
</div>
<script>
var a2a_config = a2a_config || {};
a2a_config.locale = "ar";
</script>
<script async src="https://static.addtoany.com/menu/page.js"></script>