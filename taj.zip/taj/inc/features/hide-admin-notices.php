<?php

/**
 * Register and apply hide admin notices feature only if the user enable it
 *
 * @package    taj
 */

add_action('admin_head', 'taj_hide_admin_notices_feature');

function taj_hide_admin_notices_feature()
{
    global $taj_options;
    if (isset($taj_options['taj_hide_admin_notices_switch']) && $taj_options['taj_hide_admin_notices_switch']) {
        remove_all_actions('admin_notices');
    }
}