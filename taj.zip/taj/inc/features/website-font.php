<?php

/**
 * Register and apply website font feature only if the user enable it
 *
 * @package    taj
 */

// Apply the user's chosen font family
add_action('wp_head', 'taj_website_font_feature');

function taj_website_font_feature()
{
    // Global Options
    global $taj_options;
    $taj_website_font_family = $taj_options['taj_website_font_family'];

    // google font
    if (substr($taj_website_font_family, 0, 2) === "g-") {
        // remove g- from the font name
        $taj_website_font_family = substr($taj_website_font_family, 2);
        // search for the + symbols and replace them with a space
        $taj_website_font_family  = str_replace("+", " ", $taj_website_font_family);
    }
    ?>

    <style>
    body,
    body header,
    body footer,
    body .content,
    body .sidebar,
    body p,
    body h1,
    body h2,
    body h3,
    body h4,
    body h5,
    body h6,
    body ul,
    body li,
    body div:not(:empty),
    body span:not(:empty),
    body nav,
    body nav a,
    body nav ul li,
    body input,
    body button,
    body label,
    body textarea,
    body input::placeholder,
    body textarea::placeholder {
        font-family: '<?php echo $taj_website_font_family; ?>' !important;
    }

    #wpadminbar .ab-icon,
    #wpadminbar .ab-item:before,
    #wpadminbar>#wp-toolbar>#wp-admin-bar-root-default .ab-icon,
    .wp-admin-bar-arrow {
        font-family: 'dashicons' !important;
    }

    .dashicons, .dashicons-before:before {
    font-family: 'dashicons' !important;
    }

    .lg-toolbar .lg-icon {
	font-family: 'lg' !important;
    }

    [class*=" eicon-"], [class^=eicon] {
    font-family: eicons !important;
    }
    
    </style>

    <?php

    $taj_website_font_family = $taj_options['taj_website_font_family'];
    // Add the url of the font to the head in order to load it
    // determine font link based on font name
    // if the font name start with g- that mean this is google font otherwise this is fontface font
    if (substr($taj_website_font_family, 0, 2) === "g-") { // google font
        // remove g- from the font name
        $taj_website_font_family = substr($taj_website_font_family, 2); ?>
    <link href="https://fonts.googleapis.com/css2?family=<?php echo $taj_website_font_family; ?>&display=swap" rel="stylesheet">
    <?php
    } else { // fontface font
        ?>
    <link rel="stylesheet" type="text/css" href="https://www.fontstatic.com/f=<?php echo $taj_website_font_family; ?>" />
    <?php
    }
}
