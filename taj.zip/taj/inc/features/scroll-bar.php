<?php

/**
 * Register and apply scroll bar feature only if the user enable it
 *
 * @package    taj
 */


add_action('wp_footer', 'taj_scroll_bar_feature');

function taj_scroll_bar_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_scroll_bar_width = $taj_options['taj_scroll_bar_width'];
    $taj_scroll_bar_type = $taj_options['taj_scroll_bar_type'];
    $taj_scroll_bar_show_shadow = $taj_options['taj_scroll_bar_show_shadow'];
    $taj_scroll_bar_handle_color = $taj_options['taj_scroll_bar_handle_color'];
    $taj_scroll_bar_handle_color_hover = $taj_options['taj_scroll_bar_handle_color_hover'];
    $taj_scroll_bar_track_color = $taj_options['taj_scroll_bar_track_color'];

  // set the values for scroll bar type
  if ($taj_scroll_bar_type == 1) {
    $taj_scroll_bar_type=10;
  } elseif ($taj_scroll_bar_type == 2) {
    $taj_scroll_bar_type=0;
  } elseif ($taj_scroll_bar_type == 3) {
    $taj_scroll_bar_type=4;
  }

  // set the values for scroll bar show shadow
  if ($taj_scroll_bar_show_shadow == 1) {
    $taj_scroll_bar_show_shadow="inset 0 0 6px rgba(0, 0, 0, 0.3)";
  } elseif ($taj_scroll_bar_show_shadow == 2) {
    $taj_scroll_bar_show_shadow="none";
  }


    ?>
<style>

/* width */
::-webkit-scrollbar {
  width: <?php echo $taj_scroll_bar_width; ?>px;
}

/* Track */
::-webkit-scrollbar-track {
  background: <?php echo $taj_scroll_bar_track_color; ?>;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: <?php echo $taj_scroll_bar_handle_color; ?>;
  box-shadow: <?php echo $taj_scroll_bar_show_shadow; ?>;
  border-radius: <?php echo $taj_scroll_bar_type; ?>px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: <?php echo $taj_scroll_bar_handle_color_hover; ?>;
}

</style>
<?php
}