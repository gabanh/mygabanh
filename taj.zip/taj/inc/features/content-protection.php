<?php

/**
 * Register and apply content protection feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_footer', 'taj_content_protection_feature');

function taj_content_protection_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_content_protection_text_selection = $taj_options['taj_content_protection_text_selection'];
    $taj_content_protection_right_click = $taj_options['taj_content_protection_right_click'];
    $taj_content_protection_f12 = $taj_options['taj_content_protection_f12'];
    $taj_content_protection_ctrl_u = $taj_options['taj_content_protection_ctrl_u'];
    $taj_content_protection_ctrl_shift_i = $taj_options['taj_content_protection_ctrl_shift_i'];
    $taj_content_protection_alert = $taj_options['taj_content_protection_alert'];

    // prevent text selection
    if ($taj_content_protection_text_selection == 1) {
        ?>
<style>
body {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
</style>
<?php
    }

    // prevent right click
    if ($taj_content_protection_right_click == 1) {
        ?>
<script>
window.oncontextmenu = function() {
    <?php
        if ($taj_content_protection_alert == 1) {
            ?>
    alert("<?php esc_html_e('Sorry.. The content of the site is protected.', 'taj') ?>");
    <?php
        }
        ?>
    return false; // cancel default menu
}
</script>
<?php
    }

    // prevent the keys
    if ($taj_content_protection_f12 == 1 || $taj_content_protection_ctrl_u == 1 || $taj_content_protection_ctrl_shift_i == 1) {
        ?>
<script>
document.body.onkeydown = function(e) {
    key = e.keyCode || e.charCode || e.which; //cross browser complications

    <?php
    // prevent pressing F12
if ($taj_content_protection_f12 == 1) {
    ?>
    if (key === 123) {
        <?php
    if ($taj_content_protection_alert == 1) {
        ?>
        alert("<?php esc_html_e('Sorry.. The content of the site is protected.', 'taj') ?>");
        <?php
    }
    ?>
        return false;
    }
    <?php
}
// prevent pressing Ctrl + U
if ($taj_content_protection_ctrl_u == 1) {
    ?>

    if (e.ctrlKey && key === 85) {
        <?php
    if ($taj_content_protection_alert == 1) {
        ?>
        alert("<?php esc_html_e('Sorry.. The content of the site is protected.', 'taj') ?>");
        <?php
    }
    ?>
        return false;
    }

<?php
// prevent pressing Ctrl + Shift + I
if ($taj_content_protection_ctrl_shift_i == 1) {
    ?>

    if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
        <?php
    if ($taj_content_protection_alert == 1) {
        ?>
        alert("<?php esc_html_e('Sorry.. The content of the site is protected.', 'taj') ?>");
        <?php
    }
    ?>
        return false;
    }

    <?php
}
}
        ?>

}
</script>
<?php
    }
}