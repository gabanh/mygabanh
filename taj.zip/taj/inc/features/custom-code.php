<?php

/**
 * Register and apply custom code feature only if the user enable it
 *
 * @package    taj
 */

add_action('wp_head', 'taj_custom_code_feature');

function taj_custom_code_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel

    $taj_custom_code_css = $taj_options['taj_custom_code_css'];
    $taj_custom_code_css_desktop = $taj_options['taj_custom_code_css_desktop'];
    $taj_custom_code_css_tablet = $taj_options['taj_custom_code_css_tablet'];
    $taj_custom_code_css_mobile = $taj_options['taj_custom_code_css_mobile'];
    $taj_custom_code_js = $taj_options['taj_custom_code_js'];

    // print global css custom code
    if ($taj_custom_code_css != '' ) {
        echo '<style>' . $taj_custom_code_css . '</style>';
    }

    // print desktop css custom code
    if ($taj_custom_code_css_desktop != '' ) {
        echo '<style>@media only screen and (min-width: 1025px){' . $taj_custom_code_css_desktop . '}</style>';
    }

    // print tablet css custom code
    if ($taj_custom_code_css_tablet != '' ) {
        echo '<style>@media only screen and (min-width: 481px) and (max-width: 1024px) {' . $taj_custom_code_css_tablet . '}</style>';
    }

    // print mobile css custom code
    if ($taj_custom_code_css_mobile != '' ) {
        echo '<style>@media only screen and (max-width: 480px){' . $taj_custom_code_css_mobile . '}</style>';
    }

    // print global js custom code
    if ($taj_custom_code_js != '' ) {
        echo '<script>' . $taj_custom_code_js . '</script>';
    }

}