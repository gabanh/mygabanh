<?php

/**
 * Register and apply maintenance mode feature only if the user enable it
 *
 * @package    taj
 */

 add_action('get_header', 'taj_wp_maintenance_mode_feature');

 function taj_wp_maintenance_mode_feature()
 {
     global $taj_options;
     if ($taj_options['taj_wp_maintenance_mode_switch']) {
         if (! current_user_can('edit_themes')
         || ! is_user_logged_in()) {
             wp_die(
                 '<h1>' . $taj_options['taj_wp_maintenance_mode_title'] . '</h1> <br/> ' . $taj_options['taj_wp_maintenance_mode_text'] . ' ',$taj_options['taj_wp_maintenance_mode_title']) ;
         }
     }
 }
 