<?php

/**
 * Register and apply social menu feature only if the user enable it
 *
 * @package    taj
 */


add_action('wp_footer', 'taj_social_menu_feature');

function taj_social_menu_feature()
{
    // Global Options
    global $taj_options;

    // Get the user options from Taj Control Panel
    $taj_social_menu_open_type = $taj_options['taj_social_menu_open_type'];
    $taj_social_menu_position = $taj_options['taj_social_menu_position'];
    $taj_social_menu_type = $taj_options['taj_social_menu_type'];
    $taj_social_menu_show_mobile = $taj_options['taj_social_menu_show_mobile'];
    $taj_social_menu_show_shadow = $taj_options['taj_social_menu_show_shadow'];
    $taj_social_menu_show_side_space = $taj_options['taj_social_menu_show_side_space'];
    $taj_social_menu_show_bottom_space = $taj_options['taj_social_menu_show_bottom_space'];
    $taj_social_menu_size = $taj_options['taj_social_menu_size'];
    $taj_social_menu_icon_size = $taj_options['taj_social_menu_icon_size'];

    // set the values for button open type
    if ($taj_social_menu_open_type == 1) {
        $taj_social_menu_open_type="_blank";
    } elseif ($taj_social_menu_open_type == 2) {
        $taj_social_menu_open_type="_self";
    }

    // set the values for button position
    if ($taj_social_menu_position == 1) {
        $taj_social_menu_position_right="0px";
        $taj_social_menu_position_left="auto";
        $taj_social_menu_position_start="translate(+50px, -50%)";
        $taj_social_menu_position_end="translate(-5px, -50%)";
    } elseif ($taj_social_menu_position == 2) {
        $taj_social_menu_position_right="auto";
        $taj_social_menu_position_left="0px";
        $taj_social_menu_position_start="translate(-50px, -50%)";
        $taj_social_menu_position_end="translate(+5px, -50%)";
    }

    // set the values for button type (border radius)
    if ($taj_social_menu_type == 1) {
        $taj_social_menu_type=50;
    } elseif ($taj_social_menu_type == 2) {
        $taj_social_menu_type=0;
    } elseif ($taj_social_menu_type == 3) {
        $taj_social_menu_type=10;
    }

    // set the values for button show on mobile
    if ($taj_social_menu_show_mobile == 1) {
        $taj_social_menu_show_mobile="block";
    } elseif ($taj_social_menu_show_mobile == 2) {
        $taj_social_menu_show_mobile="none";
    }

    // set the values for button show shadow
    if ($taj_social_menu_show_shadow == 1) {
        $taj_social_menu_show_shadow="1px 6px 24px 0 rgb(7 94 84 / 24%)";
    } elseif ($taj_social_menu_show_shadow == 2) {
        $taj_social_menu_show_shadow="none";
    }

    // set the values for button show side space
    // remove the space
    if ($taj_social_menu_show_side_space == 2) {
        $taj_social_menu_position_end="translate(0px, -50%)";
    }

    // set the values for button show bottom space
    if ($taj_social_menu_show_bottom_space == 1) {
        $taj_social_menu_show_bottom_space="0px 0 0.5rem 0";
    } elseif ($taj_social_menu_show_bottom_space == 2) {
        $taj_social_menu_show_bottom_space="0px";
    }


    // output the ul if the url field of any item is not empty AND any item is ENABLED
    for ($i=1; $i<11; $i++) {
        if ($taj_options['taj_social_menu_item_url' . $i] != '' && $taj_options['taj_social_menu_switch' . $i] == 1) {
            ?>

<ul class="tajSocialMenu">
    <?php
for ($i=1; $i<11; $i++) {
    $taj_social_menu_switch = $taj_options['taj_social_menu_switch' . $i];
    $taj_social_menu_item_url = $taj_options['taj_social_menu_item_url' . $i];
    $taj_social_menu_item_icon = $taj_options['taj_social_menu_item_icon' . $i];
    $taj_social_menu_icon_color = $taj_options['taj_social_menu_icon_color' . $i];
    $taj_social_menu_icon_color_hover = $taj_options['taj_social_menu_icon_color_hover' . $i];
    $taj_social_menu_icon_bg_color = $taj_options['taj_social_menu_icon_bg_color' . $i];
    $taj_social_menu_icon_bg_color_hover = $taj_options['taj_social_menu_icon_bg_color_hover' . $i];

    // output the item if the url field is not empty AND the item is ENABLED
    if ($taj_social_menu_item_url != '' && $taj_social_menu_switch == 1) {
        ?>

    <li id="item-<?php echo $i;?>"><a href="<?php echo $taj_social_menu_item_url; ?>" target="<?php echo $taj_social_menu_open_type; ?>"><i class="fa-brands fa-<?php echo $taj_social_menu_item_icon; ?>"></i></a></li>

    <style>
    .tajSocialMenu #item-<?php echo $i;?> {
        background-color: <?php echo $taj_social_menu_icon_bg_color;
        ?>;
    }

    .tajSocialMenu #item-<?php echo $i;?>:hover {
        background-color: <?php echo $taj_social_menu_icon_bg_color_hover;
        ?>;
    }

    .tajSocialMenu #item-<?php echo $i;?> i {
        color: <?php echo $taj_social_menu_icon_color;
        ?>;
    }

    .tajSocialMenu #item-<?php echo $i;?>:hover i {
        color: <?php echo $taj_social_menu_icon_color_hover;
        ?>;
    }
    </style>
    <?php
    }
}
            ?>
</ul>

<style>
.tajSocialMenu {
    display: block;
    position: fixed;
    height: auto;
    top: 50%;
    /* position starting animation from -50px on X axis (now menu is hidden) and -50% on Y axis (to vertical align the menu) */
    transform: <?php echo $taj_social_menu_position_start;
            ?>;
    right: <?php echo $taj_social_menu_position_right;
            ?>;
    left: <?php echo $taj_social_menu_position_left;
            ?>;
    padding: 0px;
    margin: 0px;
    cursor: pointer;
    opacity: 0;
    box-shadow: <?php echo $taj_social_menu_show_shadow;
            ?>;
    transition: 0.5s;
    -moz-transition: 0.5s;
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    z-index: 99999;
}

.tajSocialMenu li {
    list-style: none;
    transition: 0.5s;
    padding: 0px;
    margin: <?php echo $taj_social_menu_show_bottom_space;
            ?>;
    -moz-transition: 0.5s;
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
    border-radius: <?php echo $taj_social_menu_type;
            ?>%;
    text-align: center;
    width: <?php echo $taj_social_menu_size;
            ?>px;
    height: <?php echo $taj_social_menu_size;
            ?>px;
}

.tajSocialMenu li a {
    margin: 0px;
    display: block;
    width: 100%;
    height: 100%;
}

.tajSocialMenu i {
    font-size: <?php echo $taj_social_menu_icon_size;
            ?>px;
    line-height: <?php echo $taj_social_menu_size;
            ?>px;
    transition: 0.5s;
    -moz-transition: 0.5s;
    -webkit-transition: 0.5s;
    -o-transition: 0.5s;
}

.showtajSocialMenu {
    /* position ending animation to 0px(no space)/5px(space) on X axis (now menu is visible) and -50% on Y axis (to vertical align the menu) */
    transform: <?php echo $taj_social_menu_position_end;
            ?>;
    opacity: 1;
}

@media only screen and (max-width: 768px) {

    /* For mobile phones: */
    .showtajSocialMenu {
        display: <?php echo $taj_social_menu_show_mobile;
            ?>;
    }
}
</style>
<?php
        }
    }
}