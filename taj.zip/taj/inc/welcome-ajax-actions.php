<?php

/**
 * Handle AJAX requests to install and activate the ocdi plugin and child theme
 * @package Taj
 */

// Install and activate One Click Demo Import plugin
function taj_install_plugin_callback()
{
    if (! current_user_can('install_plugins')) {
        wp_send_json_error(esc_html__('You do not have the required permissions.', 'taj'));
    }
    // verify that an AJAX request is coming from a trusted source & verify that the nonce provided in the AJAX request (sent via _ajax_nonce) matches the expected value for the action taj_install_plugin
    check_ajax_referer('taj_install_plugin');

    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/misc.php';
    require_once ABSPATH . 'wp-admin/includes/plugin.php';

    $plugin_slug = 'one-click-demo-import';
    $plugin_file = 'one-click-demo-import/one-click-demo-import.php';

    if (file_exists(WP_PLUGIN_DIR . '/' . $plugin_file) && is_plugin_active($plugin_file)) {
        wp_send_json_success();
    }

    $api = plugins_api('plugin_information', array(
        'slug'   => $plugin_slug,
        'fields' => array( 'sections' => false )
    ));
    if (is_wp_error($api)) {
        wp_send_json_error(esc_html__('Could not fetch plugin information.', 'taj'));
    }

    // We use AJAX skin to prevent any output from being displayed during installation for pure responsiveness of json
    $skin = new WP_Ajax_Upgrader_Skin();
    $upgrader = new Plugin_Upgrader($skin);
    $result = $upgrader->install($api->download_link);
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    $activate = activate_plugin($plugin_file);
    if (is_wp_error($activate)) {
        wp_send_json_error($activate->get_error_message());
    }

    wp_send_json_success();
}
add_action('wp_ajax_taj_install_plugin', 'taj_install_plugin_callback');


// Install and activate the child theme and extracting the zip file
function taj_install_child_theme_callback()
{
    if (! current_user_can('switch_themes')) {
        wp_send_json_error(esc_html__('You do not have the required permissions.', 'taj'));
    }
    check_ajax_referer('taj_install_child_theme');

    // Include files needed to handle compressed files
    require_once ABSPATH . 'wp-admin/includes/file.php';
    WP_Filesystem();
    require_once ABSPATH . 'wp-admin/includes/misc.php';

    // Expected child theme folder name after extracting the file
    $child_theme_slug = 'taj-child';
    $theme_root       = get_theme_root();
    $child_theme_dir  = $theme_root . '/' . $child_theme_slug;

    // If the child theme already exists in the themes folder
    if (is_dir($child_theme_dir)) {
        if (wp_get_theme()->get_stylesheet() !== $child_theme_slug) {
            switch_theme($child_theme_slug);
        }
        wp_send_json_success();
    }

    // Path of the child theme zip file inside the child-theme folder of the main theme
    $source = get_template_directory() . '/child-theme/taj-child.zip';
    if (! file_exists($source)) {
        wp_send_json_error(esc_html__('The child theme file does not exist.', 'taj'));
    }

    // Extract the zip file to the themes folder
    $result = unzip_file($source, $theme_root);
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    // Ensure that the child theme is extracted and then activate it
    if (is_dir($child_theme_dir)) {
        switch_theme($child_theme_slug);
        wp_send_json_success();
    } else {
        wp_send_json_error(esc_html__('Failed to extract child theme.', 'taj'));
    }
}
add_action('wp_ajax_taj_install_child_theme', 'taj_install_child_theme_callback');
