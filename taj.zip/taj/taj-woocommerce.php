<?php
/**
 * Template Name: Taj WooCommerce
 *
 * This is the template for display Cart + Checkout + My Account WooCommerce pages.
 *
 * @package Taj
 */

get_header();

global $taj_options;

if ($taj_options['taj_page_titles_switch']) {
    echo do_shortcode($taj_options['taj_page_titles_shortcode']);
}

?>
<div class="container taj-wrap">

    <div class="row">

        <main id="primary" class="site-main">

            <?php
        while (have_posts()) :
            the_post();

            get_template_part('template-parts/content', 'page');


        endwhile; // End of the loop.
?>

        </main><!-- #main -->

    </div>
</div>

<?php
get_footer();
