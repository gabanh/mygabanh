<?php
/**
 * The template for displaying archive & category & author pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Taj
 */

get_header();

global $taj_options;

if ($taj_options['taj_page_titles_switch']) {
    echo do_shortcode($taj_options['taj_page_titles_shortcode']);
}

?>
<div class="container taj-wrap">


<div class="row">


 <!-- Right Sidebar -->
 <?php if ($taj_options['archive_layout'] == 3): ?>
        <div class="col-md-3">
            <?php
            get_sidebar();
     ?>
        </div>
        <?php endif; ?>

   <!-- No Sidebar -->
   <?php if ($taj_options['archive_layout'] == 1): ?>
        <div class="col-md-12">

            <!-- Right or Left Sidebar -->
            <?php else: ?>
            <div class="col-md-9">
                <?php endif; ?>

	<main id="primary" class="site-main">

		<?php if (have_posts()) : ?>

			<header class="page-header">
				<?php
         // we do not want to show the title here because we have the Page Title (Taj) elementor widget that will show the correct title
         the_archive_description('<div class="archive-description">', '</div>');
		    ?>
			</header><!-- .page-header -->

			<?php
            /* Start the Loop */
            while (have_posts()) :
                the_post();

                /*
                 * Include the Post-Type-specific template for the content.
                 * If you want to override this in a child theme, then include a file
                 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                 */
                get_template_part('template-parts/content', get_post_type());

            endwhile;

		    the_posts_navigation();

		else :

		    get_template_part('template-parts/content', 'none');

		endif;
?>

	</main><!-- #main -->
 </div>
  


       <!-- Left Sidebar -->
	   <?php if ($taj_options['archive_layout'] == 2): ?>
            <div class="col-md-3">
                <?php
    get_sidebar();
	       ?>
            </div>
            <?php endif; ?>

   </div>

</div>
<?php
get_footer();
